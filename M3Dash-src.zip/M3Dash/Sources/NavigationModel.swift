import Foundation
import SwiftUI
import Combine
import MapKit
import CoreLocation
import AVFoundation

/// A line drawn on the map (travelled part in grey, remaining part in blue, alternatives dimmed).
struct RouteLine: Identifiable {
    let id: String
    let coordinates: [CLLocationCoordinate2D]
    let color: Color
    let width: CGFloat
}

/// A pin on the map.
struct MapPin: Identifiable {
    var id: String { "\(name)|\(coordinate.latitude)|\(coordinate.longitude)" }
    let name: String
    let coordinate: CLLocationCoordinate2D
}

/// Destination search (MKLocalSearchCompleter + MKLocalSearch), routing (MKDirections, with
/// alternatives and avoid highways/tolls), and turn-by-turn progress from CLLocation updates.
/// Not actor-isolated: MapKit calls back on the main thread, and every UI-facing change
/// is made on the main queue.
final class NavigationModel: NSObject, ObservableObject, MKLocalSearchCompleterDelegate {
    // Search
    @Published var query: String = "" {
        didSet {
            if query.trimmingCharacters(in: .whitespaces).isEmpty {
                suggestions = []
            } else {
                completer.queryFragment = query
            }
        }
    }
    @Published private(set) var suggestions: [MKLocalSearchCompletion] = []
    @Published private(set) var isSearching = false

    // Route
    @Published private(set) var destination: MKMapItem?
    @Published private(set) var destinationName: String = ""
    @Published private(set) var routes: [MKRoute] = []
    @Published var selectedRouteIndex: Int = 0 {
        didSet { if selectedRouteIndex != oldValue { prepareRoute() } }
    }
    @Published private(set) var isRouting = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var isNavigating = false

    // Progress
    @Published private(set) var nextInstruction: String?
    @Published private(set) var distanceToNext: CLLocationDistance?
    @Published private(set) var remainingDistance: CLLocationDistance?
    @Published private(set) var remainingTime: TimeInterval?
    @Published private(set) var travelledIndex: Int = 0
    @Published private(set) var arrived = false

    // Options (persisted; same keys as the Settings toggles)
    var avoidHighways: Bool {
        get { UserDefaults.standard.bool(forKey: "navAvoidHighways") }
        set { UserDefaults.standard.set(newValue, forKey: "navAvoidHighways"); objectWillChange.send() }
    }
    var avoidTolls: Bool {
        get { UserDefaults.standard.bool(forKey: "navAvoidTolls") }
        set { UserDefaults.standard.set(newValue, forKey: "navAvoidTolls"); objectWillChange.send() }
    }
    private var voiceEnabled: Bool { UserDefaults.standard.bool(forKey: "navVoice") }

    private let completer = MKLocalSearchCompleter()
    private weak var location: LocationService?
    private var cancellables = Set<AnyCancellable>()
    private let speech = AVSpeechSynthesizer()

    // Route geometry
    private(set) var routeCoords: [CLLocationCoordinate2D] = []
    private var cumulative: [Double] = []        // metres from route start to each coordinate
    private var stepStarts: [Double] = []        // metres from route start to each step's maneuver
    private var nextStepIndex: Int?
    private var announcedFar: Int?
    private var announcedNear: Int?
    private var offRouteCount = 0
    private var lastReroute = Date.distantPast

    override init() {
        super.init()
        completer.delegate = self
        completer.resultTypes = [.address, .pointOfInterest]
    }

    func attach(_ location: LocationService) {
        self.location = location
        cancellables.removeAll()   // safe to call more than once
        location.$location
            .sink { [weak self] loc in
                guard let self, let loc else { return }
                self.updateProgress(with: loc)
                self.completer.region = MKCoordinateRegion(center: loc.coordinate,
                                                           latitudinalMeters: 80_000,
                                                           longitudinalMeters: 80_000)
            }
            .store(in: &cancellables)
    }

    var activeRoute: MKRoute? {
        guard selectedRouteIndex >= 0, selectedRouteIndex < routes.count else { return nil }
        return routes[selectedRouteIndex]
    }

    var hasRoute: Bool { activeRoute != nil }

    var eta: Date? { remainingTime.map { Date().addingTimeInterval($0) } }

    // MARK: Search

    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        let results = Array(completer.results.prefix(12))
        DispatchQueue.main.async { self.suggestions = results }
    }

    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        DispatchQueue.main.async { self.suggestions = [] }
    }

    /// Resolves a suggestion into a map item, then asks for routes to it.
    func choose(_ completion: MKLocalSearchCompletion) {
        let request = MKLocalSearch.Request(completion: completion)
        if let loc = location?.location {
            request.region = MKCoordinateRegion(center: loc.coordinate, latitudinalMeters: 80_000, longitudinalMeters: 80_000)
        }
        isSearching = true
        errorMessage = nil
        let fallbackName = completion.title
        MKLocalSearch(request: request).start { [weak self] response, _ in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isSearching = false
                guard let item = response?.mapItems.first else {
                    self.errorMessage = "Couldn't find that place. Search and routing use cellular data, since the Commander's Wi-Fi has no internet."
                    return
                }
                self.setDestination(item, name: item.name ?? fallbackName)
            }
        }
    }

    /// Searches free text (Return key in the search field) and routes to the best match.
    func searchText() {
        let text = query.trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = text
        if let loc = location?.location {
            request.region = MKCoordinateRegion(center: loc.coordinate, latitudinalMeters: 80_000, longitudinalMeters: 80_000)
        }
        isSearching = true
        errorMessage = nil
        MKLocalSearch(request: request).start { [weak self] response, _ in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isSearching = false
                guard let item = response?.mapItems.first else {
                    self.errorMessage = "No results. Search and routing use cellular data, since the Commander's Wi-Fi has no internet."
                    return
                }
                self.setDestination(item, name: item.name ?? text)
            }
        }
    }

    private func setDestination(_ item: MKMapItem, name: String) {
        destination = item
        destinationName = name
        suggestions = []
        calculateRoutes()
    }

    // MARK: Routing

    func calculateRoutes() {
        guard let destination else { return }
        let request = MKDirections.Request()
        request.source = MKMapItem.forCurrentLocation()
        request.destination = destination
        request.transportType = .automobile
        request.requestsAlternateRoutes = true
        request.highwayPreference = avoidHighways ? .avoid : .any
        request.tollPreference = avoidTolls ? .avoid : .any
        isRouting = true
        errorMessage = nil
        MKDirections(request: request).calculate { [weak self] response, error in
            DispatchQueue.main.async {
                guard let self else { return }
                self.isRouting = false
                guard let found = response?.routes, !found.isEmpty else {
                    if error != nil {
                        self.errorMessage = "Couldn't get directions. Routing needs cellular data (the Commander's Wi-Fi has no internet). Try again in a moment."
                    } else {
                        self.errorMessage = "No driving route found."
                    }
                    return
                }
                self.routes = found
                if self.selectedRouteIndex != 0 {
                    self.selectedRouteIndex = 0   // didSet prepares the route
                } else {
                    self.prepareRoute()
                }
                if self.isNavigating, let loc = self.location?.location {
                    self.updateProgress(with: loc)
                }
            }
        }
    }

    func startNavigation() {
        guard activeRoute != nil else { return }
        isNavigating = true
        arrived = false
        location?.setNavigationAccuracy(true)
        announcedFar = nil
        announcedNear = nil
        if let loc = location?.location { updateProgress(with: loc) }
        if let instruction = nextInstruction {
            speak("Starting route. \(instruction)")
        } else {
            speak("Starting route to \(destinationName).")
        }
    }

    /// Ends guidance and clears the route.
    func endNavigation() {
        isNavigating = false
        location?.setNavigationAccuracy(false)
        speech.stopSpeaking(at: .immediate)
        destination = nil
        destinationName = ""
        routes = []
        routeCoords = []
        cumulative = []
        stepStarts = []
        nextStepIndex = nil
        nextInstruction = nil
        distanceToNext = nil
        remainingDistance = nil
        remainingTime = nil
        travelledIndex = 0
        errorMessage = nil
        query = ""
    }

    func clearError() { errorMessage = nil }

    /// Builds the coordinate list, cumulative distances, and step start distances for the active route.
    private func prepareRoute() {
        guard let route = activeRoute else { return }
        let polyline = route.polyline
        let count = polyline.pointCount
        var coords = [CLLocationCoordinate2D](repeating: kCLLocationCoordinate2DInvalid, count: count)
        if count > 0 {
            polyline.getCoordinates(&coords, range: NSRange(location: 0, length: count))
        }
        var cum: [Double] = []
        cum.reserveCapacity(count)
        var total = 0.0
        for i in 0..<coords.count {
            if i > 0 {
                total += MKMapPoint(coords[i - 1]).distance(to: MKMapPoint(coords[i]))
            }
            cum.append(total)
        }
        var starts: [Double] = []
        var acc = 0.0
        for step in route.steps {
            starts.append(acc)
            acc += step.distance
        }
        routeCoords = coords
        cumulative = cum
        stepStarts = starts
        travelledIndex = 0
        nextStepIndex = nil
        announcedFar = nil
        announcedNear = nil
        offRouteCount = 0
        remainingDistance = route.distance
        remainingTime = route.expectedTravelTime
        let firstReal = route.steps.firstIndex { !$0.instructions.isEmpty && $0.distance > 0 }
        nextInstruction = firstReal.map { route.steps[$0].instructions }
        distanceToNext = nil
    }

    // MARK: Progress

    private func updateProgress(with loc: CLLocation) {
        guard isNavigating, let route = activeRoute, routeCoords.count > 1, cumulative.count == routeCoords.count else { return }
        let here = MKMapPoint(loc.coordinate)

        // Nearest route vertex, searched from a little behind the last match.
        let startIdx = max(0, travelledIndex - 30)
        var bestIdx = travelledIndex
        var bestDist = Double.greatestFiniteMagnitude
        for i in startIdx..<routeCoords.count {
            let d = here.distance(to: MKMapPoint(routeCoords[i]))
            if d < bestDist {
                bestDist = d
                bestIdx = i
            }
        }

        // Off route: reroute after 3 bad fixes, at most every 20 s.
        if bestDist > 80 {
            offRouteCount += 1
            if offRouteCount >= 3, Date().timeIntervalSince(lastReroute) > 20 {
                lastReroute = Date()
                offRouteCount = 0
                speak("Rerouting.")
                calculateRoutes()
            }
            return
        }
        offRouteCount = 0

        if bestIdx != travelledIndex { travelledIndex = bestIdx }
        let progress = cumulative[bestIdx]
        let remaining = max(0, route.distance - progress)
        remainingDistance = remaining
        remainingTime = route.distance > 0 ? route.expectedTravelTime * remaining / route.distance : nil

        // Next maneuver = first step that starts ahead of us.
        var next: Int?
        for (i, start) in stepStarts.enumerated() where i < route.steps.count {
            if start > progress + 5 && !route.steps[i].instructions.isEmpty {
                next = i
                break
            }
        }
        if let n = next {
            let step = route.steps[n]
            let dist = stepStarts[n] - progress
            nextInstruction = step.instructions
            distanceToNext = dist
            if n != nextStepIndex {
                nextStepIndex = n
                announcedFar = nil
                announcedNear = nil
            }
            announce(step: n, instruction: step.instructions, distance: dist)
        } else {
            nextInstruction = "Arrive at \(destinationName)"
            distanceToNext = remaining
        }

        if remaining < 30 && !arrived {
            arrived = true
            speak("You have arrived at \(destinationName).")
            DispatchQueue.main.asyncAfter(deadline: .now() + 8) { [weak self] in
                guard let self, self.arrived else { return }
                self.endNavigation()
            }
        }
    }

    private func announce(step: Int, instruction: String, distance: Double) {
        if distance > 300 && distance < 1300 && announcedFar != step {
            announcedFar = step
            speak("In \(NavFormat.spokenDistance(distance)), \(instruction)")
        } else if distance <= 120 && announcedNear != step {
            announcedNear = step
            announcedFar = step
            speak(instruction)
        }
    }

    private func speak(_ text: String) {
        guard voiceEnabled else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .voicePrompt, options: [.duckOthers, .interruptSpokenAudioAndMixWithOthers])
        try? session.setActive(true)
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        speech.speak(utterance)
    }

    // MARK: Map content

    /// Grey for the travelled part, blue for the rest, dimmed lines for alternative routes.
    var mapLines: [RouteLine] {
        var lines: [RouteLine] = []
        if !isNavigating {
            for (i, r) in routes.enumerated() where i != selectedRouteIndex {
                lines.append(RouteLine(id: "alt\(i)", coordinates: NavigationModel.coordinates(of: r.polyline),
                                       color: Color.gray.opacity(0.7), width: 6))
            }
        }
        guard routeCoords.count > 1 else { return lines }
        let idx = min(max(travelledIndex, 0), routeCoords.count - 1)
        if isNavigating && idx > 0 {
            lines.append(RouteLine(id: "done", coordinates: Array(routeCoords[0...idx]),
                                   color: Color.gray, width: 7))
        }
        let rest = isNavigating ? Array(routeCoords[idx...]) : routeCoords
        if rest.count > 1 {
            lines.append(RouteLine(id: "todo", coordinates: rest, color: Color.blue, width: 7))
        }
        return lines
    }

    var pins: [MapPin] {
        guard let destination else { return [] }
        return [MapPin(name: destinationName, coordinate: destination.placemark.coordinate)]
    }

    static func coordinates(of polyline: MKPolyline) -> [CLLocationCoordinate2D] {
        let count = polyline.pointCount
        guard count > 0 else { return [] }
        var coords = [CLLocationCoordinate2D](repeating: kCLLocationCoordinate2DInvalid, count: count)
        polyline.getCoordinates(&coords, range: NSRange(location: 0, length: count))
        return coords
    }

    /// Map rect for previewing all routes.
    var previewRect: MKMapRect? {
        guard !routes.isEmpty else { return nil }
        var rect = routes[0].polyline.boundingMapRect
        for r in routes.dropFirst() { rect = rect.union(r.polyline.boundingMapRect) }
        return rect.insetBy(dx: -rect.size.width * 0.15, dy: -rect.size.height * 0.15)
    }
}

// MARK: - Formatting

enum NavFormat {
    static var metric: Bool { UserDefaults.standard.bool(forKey: "metric") }

    /// "0.4 mi" / "500 ft" / "1.2 km" / "300 m".
    static func distance(_ meters: Double?) -> String {
        guard let m = meters, m.isFinite else { return "––" }
        if metric {
            if m < 1000 { return "\(Int((m / 10).rounded() * 10)) m" }
            return String(format: "%.1f km", m / 1000)
        }
        let miles = m / 1609.344
        if miles < 0.1 {
            let feet = m * 3.28084
            return "\(Int((feet / 50).rounded() * 50)) ft"
        }
        return miles < 10 ? String(format: "%.1f mi", miles) : String(format: "%.0f mi", miles)
    }

    static func spokenDistance(_ meters: Double) -> String {
        if metric {
            if meters < 1000 { return "\(Int((meters / 50).rounded() * 50)) meters" }
            return String(format: "%.1f kilometers", meters / 1000)
        }
        let miles = meters / 1609.344
        if miles < 0.2 { return "\(Int((meters * 3.28084 / 100).rounded() * 100)) feet" }
        if miles < 0.4 { return "a quarter mile" }
        if miles < 0.7 { return "half a mile" }
        return String(format: "%.1f miles", miles)
    }

    static func duration(_ seconds: Double?) -> String {
        guard let s = seconds, s.isFinite else { return "––" }
        let mins = Int((s / 60).rounded())
        if mins >= 60 { return "\(mins / 60) h \(mins % 60) min" }
        return "\(max(mins, 1)) min"
    }

    /// SF Symbol guessed from the maneuver text (MKRoute.Step has no maneuver type).
    static func maneuverSymbol(_ instruction: String?) -> String {
        guard let text = instruction?.lowercased() else { return "arrow.up" }
        if text.contains("arrive") || text.contains("destination") { return "mappin.and.ellipse" }
        if text.contains("u-turn") || text.contains("make a u") { return "arrow.uturn.left" }
        if text.contains("roundabout") || text.contains("rotary") { return "arrow.clockwise" }
        if text.contains("exit") || text.contains("ramp") {
            return text.contains("left") ? "arrow.up.left" : "arrow.up.right"
        }
        if text.contains("merge") { return "arrow.merge" }
        if text.contains("slight left") || text.contains("keep left") || text.contains("bear left") { return "arrow.up.left" }
        if text.contains("slight right") || text.contains("keep right") || text.contains("bear right") { return "arrow.up.right" }
        if text.contains("left") { return "arrow.turn.up.left" }
        if text.contains("right") { return "arrow.turn.up.right" }
        return "arrow.up"
    }
}
