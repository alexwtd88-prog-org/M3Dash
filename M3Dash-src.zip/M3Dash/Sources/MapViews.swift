import SwiftUI
import MapKit
import CoreLocation

// MARK: - Map

/// MapKit map that follows the user, heading-up or north-up, with the route drawn on top.
struct NavMapView: View {
    @EnvironmentObject var nav: NavigationModel
    @AppStorage("mapHeadingUp") private var headingUp = true
    @State private var position: MapCameraPosition = .userLocation(followsHeading: true, fallback: .automatic)
    var showsControls = true

    var body: some View {
        Map(position: $position) {
            UserAnnotation()
            ForEach(nav.mapLines) { line in
                MapPolyline(coordinates: line.coordinates)
                    .stroke(line.color, lineWidth: line.width)
            }
            ForEach(nav.pins) { pin in
                Marker(pin.name, coordinate: pin.coordinate)
                    .tint(Color.red)
            }
        }
        .mapStyle(.standard(elevation: .realistic))
        .mapControls {
            MapCompass()
            MapScaleView()
        }
        .overlay(alignment: .topTrailing) {
            if showsControls {
                MapCameraButtons(headingUp: $headingUp, following: position.followsUserLocation, recenter: follow)
                    .padding(8)
            }
        }
        .onAppear { follow() }
        .onChange(of: headingUp) { _, _ in follow() }
        .onChange(of: nav.routes.count) { _, _ in previewOrFollow() }
        .onChange(of: nav.selectedRouteIndex) { _, _ in previewOrFollow() }
        .onChange(of: nav.isNavigating) { _, _ in previewOrFollow() }
    }

    private func follow() {
        withAnimation { position = .userLocation(followsHeading: headingUp, fallback: .automatic) }
    }

    private func previewOrFollow() {
        if !nav.isNavigating, let rect = nav.previewRect {
            withAnimation { position = .rect(rect) }
        } else {
            follow()
        }
    }
}

/// Heading-up / north-up toggle plus a recenter button.
struct MapCameraButtons: View {
    @Binding var headingUp: Bool
    let following: Bool
    let recenter: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Button {
                headingUp.toggle()
            } label: {
                Image(systemName: headingUp ? "location.north.line.fill" : "location.north.line")
                    .frame(width: 40, height: 40)
            }
            .accessibilityLabel(headingUp ? "Heading up" : "North up")
            Divider().frame(width: 40)
            Button(action: recenter) {
                Image(systemName: following ? "location.fill" : "location")
                    .frame(width: 40, height: 40)
            }
            .accessibilityLabel("Recenter")
        }
        .font(.system(size: 17, weight: .semibold))
        .foregroundStyle(Color.blue)
        .background(RoundedRectangle(cornerRadius: 10).fill(.regularMaterial))
        .buttonStyle(.plain)
    }
}

// MARK: - Guidance pieces

/// Next maneuver: arrow, distance to it, and the instruction text.
struct NextTurnCard: View {
    @EnvironmentObject var nav: NavigationModel
    var compact = false
    @Environment(\.dashScale) private var scale

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: NavFormat.maneuverSymbol(nav.nextInstruction))
                .font(.system(size: (compact ? 30 : 40) * scale, weight: .bold))
                .frame(width: (compact ? 40 : 54) * scale)
            VStack(alignment: .leading, spacing: 2) {
                Text(NavFormat.distance(nav.distanceToNext))
                    .font(.system(size: (compact ? 22 : 30) * scale, weight: .bold))
                    .monospacedDigit()
                Text(nav.nextInstruction ?? "Follow the route")
                    .font(.system(size: (compact ? 14 : 17) * scale, weight: .semibold))
                    .lineLimit(2)
                    .minimumScaleFactor(0.7)
            }
            Spacer(minLength: 0)
            VoiceToggleButton()
        }
        .foregroundStyle(Color.white)
        .padding(compact ? 10 : 14)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color(red: 0.08, green: 0.36, blue: 0.22)))
    }
}

struct VoiceToggleButton: View {
    @AppStorage("navVoice") private var voice = false

    var body: some View {
        Button {
            voice.toggle()
        } label: {
            Image(systemName: voice ? "speaker.wave.2.fill" : "speaker.slash.fill")
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 36, height: 36)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(voice ? "Mute voice guidance" : "Turn on voice guidance")
    }
}

/// ETA, remaining distance and time, and estimated battery on arrival.
struct TripProgressStrip: View {
    @EnvironmentObject var nav: NavigationModel
    @EnvironmentObject var store: VehicleStore
    var compact = false
    @Environment(\.dashScale) private var scale

    var body: some View {
        HStack(spacing: compact ? 10 : 16) {
            item(etaText, "arrival")
            item(NavFormat.duration(nav.remainingTime), "left")
            item(NavFormat.distance(nav.remainingDistance), "to go")
            item(batteryText, "on arrival", tint: batteryTint)
            Spacer(minLength: 0)
            Button(role: .destructive) {
                nav.endNavigation()
            } label: {
                Text("End")
                    .font(.system(size: 15 * scale, weight: .bold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background(Capsule().fill(Color.red))
                    .foregroundStyle(Color.white)
            }
            .buttonStyle(.plain)
        }
        .padding(compact ? 8 : 12)
        .background(RoundedRectangle(cornerRadius: 14).fill(.regularMaterial))
    }

    private func item(_ value: String, _ label: String, tint: Color = .primary) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(value)
                .font(.system(size: (compact ? 15 : 18) * scale, weight: .bold))
                .monospacedDigit()
                .foregroundStyle(tint)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .font(.system(size: (compact ? 10 : 12) * scale, weight: .medium))
                .foregroundStyle(.secondary)
        }
    }

    private var etaText: String {
        guard let eta = nav.eta else { return "––" }
        return eta.formatted(date: .omitted, time: .shortened)
    }

    private var arrivalSOC: Double? {
        guard let m = nav.remainingDistance else { return nil }
        return store.arrivalSOC(remainingMiles: m / 1609.344)
    }

    private var batteryText: String {
        guard let soc = arrivalSOC else { return "––" }
        return "\(Int(max(soc, 0).rounded()))%"
    }

    private var batteryTint: Color {
        guard let soc = arrivalSOC else { return .primary }
        return soc < 10 ? .red : (soc < 20 ? .orange : .green)
    }
}

/// Route choices (alternatives), avoid options, and the Go button.
struct RouteOptionsCard: View {
    @EnvironmentObject var nav: NavigationModel
    @EnvironmentObject var store: VehicleStore
    var compact = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(nav.destinationName)
                    .font(.headline)
                    .lineLimit(1)
                Spacer()
                Button {
                    nav.endNavigation()
                } label: {
                    Image(systemName: "xmark.circle.fill").font(.title3)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }
            ForEach(Array(nav.routes.enumerated()), id: \.offset) { pair in
                RouteRow(route: pair.element,
                         selected: pair.offset == nav.selectedRouteIndex,
                         arrival: store.arrivalSOC(remainingMiles: pair.element.distance / 1609.344))
                    .onTapGesture { nav.selectedRouteIndex = pair.offset }
            }
            if !compact {
                HStack(spacing: 16) {
                    Toggle("Avoid highways", isOn: Binding(get: { nav.avoidHighways },
                                                           set: { nav.avoidHighways = $0; nav.calculateRoutes() }))
                    Toggle("Avoid tolls", isOn: Binding(get: { nav.avoidTolls },
                                                        set: { nav.avoidTolls = $0; nav.calculateRoutes() }))
                }
                .font(.footnote)
                .toggleStyle(.button)
            }
            Button {
                nav.startNavigation()
            } label: {
                Text("Go")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.green))
                    .foregroundStyle(Color.white)
            }
            .buttonStyle(.plain)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 16).fill(.regularMaterial))
    }
}

struct RouteRow: View {
    let route: MKRoute
    let selected: Bool
    let arrival: Double?

    var body: some View {
        HStack {
            Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(selected ? Color.blue : Color.secondary)
            VStack(alignment: .leading, spacing: 1) {
                Text(NavFormat.duration(route.expectedTravelTime))
                    .font(.subheadline.weight(.bold))
                Text(route.name.isEmpty ? "Route" : "via \(route.name)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 1) {
                Text(NavFormat.distance(route.distance))
                    .font(.subheadline.weight(.semibold))
                    .monospacedDigit()
                if let a = arrival {
                    Text("\(Int(max(a, 0).rounded()))% on arrival")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .contentShape(Rectangle())
    }
}

struct NavErrorBanner: View {
    @EnvironmentObject var nav: NavigationModel

    var body: some View {
        if let message = nav.errorMessage {
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "antenna.radiowaves.left.and.right.slash")
                Text(message).font(.footnote)
                Spacer(minLength: 0)
                Button {
                    nav.clearError()
                } label: {
                    Image(systemName: "xmark")
                }
                .buttonStyle(.plain)
            }
            .padding(10)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.orange.opacity(0.9)))
            .foregroundStyle(Color.black)
        }
    }
}

// MARK: - Destination search

struct DestinationSearchSheet: View {
    @EnvironmentObject var nav: NavigationModel
    @Environment(\.dismiss) private var dismiss
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("Search for a place or address", text: $nav.query)
                        .focused($focused)
                        .submitLabel(.search)
                        .autocorrectionDisabled()
                        .onSubmit {
                            nav.searchText()
                            dismiss()
                        }
                }
                if nav.isSearching || nav.isRouting {
                    HStack { ProgressView(); Text("Finding route…").foregroundStyle(.secondary) }
                }
                Section {
                    ForEach(nav.suggestions, id: \.self) { s in
                        Button {
                            nav.choose(s)
                            dismiss()
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(s.title).foregroundStyle(.primary)
                                if !s.subtitle.isEmpty {
                                    Text(s.subtitle).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                } footer: {
                    Text("Search and directions use cellular data. The Commander's Wi-Fi has no internet.")
                }
            }
            .navigationTitle("Destination")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .onAppear { focused = true }
        }
    }
}

// MARK: - Portrait Map tab

struct MapTab: View {
    @EnvironmentObject var nav: NavigationModel
    @EnvironmentObject var location: LocationService
    @State private var showSearch = false

    var body: some View {
        ZStack {
            NavMapView()
                .ignoresSafeArea(edges: .top)
            VStack(spacing: 8) {
                topArea
                NavErrorBanner()
                Spacer()
                bottomArea
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .sheet(isPresented: $showSearch) {
            DestinationSearchSheet().environmentObject(nav)
        }
    }

    @ViewBuilder
    private var topArea: some View {
        if nav.isNavigating {
            NextTurnCard()
        } else {
            Button {
                showSearch = true
            } label: {
                HStack {
                    Image(systemName: "magnifyingglass")
                    Text(nav.destinationName.isEmpty ? "Where to?" : nav.destinationName)
                        .lineLimit(1)
                    Spacer()
                    if nav.isSearching || nav.isRouting { ProgressView() }
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 14).fill(.regularMaterial))
            }
            .buttonStyle(.plain)
            .padding(.trailing, 52)   // leave room for the camera buttons
        }
        if !location.isAuthorized && location.authorization != .notDetermined {
            Text("Location is off for M3 Dash. Turn it on in Settings > Privacy > Location Services to use the map.")
                .font(.footnote)
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 12).fill(.regularMaterial))
        }
    }

    @ViewBuilder
    private var bottomArea: some View {
        if nav.isNavigating {
            TripProgressStrip()
        } else if nav.hasRoute {
            RouteOptionsCard()
        }
    }
}

// MARK: - Landscape map panel

struct NavPanel: View {
    @EnvironmentObject var nav: NavigationModel
    let onSearch: () -> Void

    var body: some View {
        ZStack {
            NavMapView()
                .clipShape(RoundedRectangle(cornerRadius: 18))
            VStack(spacing: 6) {
                if nav.isNavigating {
                    NextTurnCard(compact: true)
                } else {
                    searchButton
                }
                NavErrorBanner()
                Spacer()
                if nav.isNavigating {
                    TripProgressStrip(compact: true)
                } else if nav.hasRoute {
                    RouteOptionsCard(compact: true)
                }
            }
            .padding(8)
        }
    }

    private var searchButton: some View {
        HStack {
            Button(action: onSearch) {
                HStack(spacing: 6) {
                    Image(systemName: "magnifyingglass")
                    Text(nav.destinationName.isEmpty ? "Where to?" : nav.destinationName)
                        .lineLimit(1)
                }
                .font(.system(size: 15, weight: .semibold))
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(Capsule().fill(.regularMaterial))
            }
            .buttonStyle(.plain)
            Spacer()
        }
        .padding(.trailing, 48)
    }
}
