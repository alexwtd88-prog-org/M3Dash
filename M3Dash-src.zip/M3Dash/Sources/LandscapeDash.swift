import SwiftUI
import UIKit

/// Full-screen, Tesla-style cluster shown when the phone is turned sideways.
struct LandscapeDash: View {
    @EnvironmentObject var store: VehicleStore
    @AppStorage("nightDim") private var nightDim = false
    @State private var showSettings = false
    @AppStorage("landscapeDriveGraph") private var showDriveGraph = true

    var body: some View {
        let u = Units(metric: store.metric)
        ZStack {
            Color(white: 0.04).ignoresSafeArea()

            VStack(spacing: 0) {
                topBar
                    .padding(.top, 6)

                ZStack {
                    HStack(spacing: 0) {
                        TireCar(labels: pressureLabels)
                            .frame(maxWidth: .infinity)
                        SpeedDial(speed: u.speed(store.speedMph),
                                  unit: u.speedLabel,
                                  gear: store.gearLetter)
                            .layoutPriority(1)
                        Group {
                            if showDriveGraph {
                                CurrentDriveCard(compact: true)
                                    .padding(.trailing, 72)
                                    .padding(.leading, 8)
                            } else {
                                TireCar(labels: tempLabels)
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .contentShape(Rectangle())
                        .onTapGesture { withAnimation(.easeInOut(duration: 0.2)) { showDriveGraph.toggle() } }
                    }
                    VStack {
                        HStack {
                            Spacer()
                            SpeedLimitPill(limit: store.snap.speedLimit)
                        }
                        Spacer()
                    }
                }
                .frame(maxHeight: .infinity)

                bottomBar(u)
                    .padding(.bottom, 6)
            }
            .padding(.horizontal, 18)

            if nightDim {
                Color.black.opacity(0.45).ignoresSafeArea().allowsHitTesting(false)
            }
        }
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .sheet(isPresented: $showSettings) { SettingsView() }
    }

    // MARK: Top bar

    private var topBar: some View {
        TimelineView(.periodic(from: .now, by: 1)) { ctx in
            HStack(spacing: 14) {
                Text(ctx.date, format: .dateTime.hour().minute())
                    .font(.system(size: 26, weight: .semibold))
                    .monospacedDigit()

                HStack(spacing: 4) {
                    Image(systemName: "sun.max.fill").foregroundStyle(.yellow)
                    Text(tempText(store.snap.outsideTempC))
                    Text("·").foregroundStyle(.secondary)
                    Image(systemName: "car.fill")
                    Text(tempText(store.snap.cabinTempC))
                }
                .font(.system(size: 22, weight: .semibold))

                if store.status == .connecting {
                    ProgressView().tint(.white)
                }

                Spacer()

                ConnectionPill()

                PhoneBattery()

                Button {
                    store.keepAwake.toggle()
                    UIApplication.shared.isIdleTimerDisabled = store.keepAwake
                } label: {
                    Image(systemName: store.keepAwake ? "lightbulb.fill" : "lightbulb")
                }

                Button { nightDim.toggle() } label: {
                    Image(systemName: nightDim ? "moon.fill" : "moon")
                }

                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                }
            }
            .font(.system(size: 22, weight: .semibold))
            .foregroundStyle(.white)
            .buttonStyle(.plain)
        }
    }

    // MARK: Bottom bar

    private func bottomBar(_ u: Units) -> some View {
        HStack(alignment: .firstTextBaseline) {
            HStack(spacing: 10) {
                MiniBattery(percent: store.socPercent)
                Text("\(Fmt.num(store.socPercent, 0))%")
                    + Text(" / ").foregroundColor(.secondary)
                    + Text("\(Fmt.num(u.dist(store.rangeMiles), 0))\(u.distLabel)")
            }
            .font(.system(size: 26, weight: .semibold))
            .monospacedDigit()

            Spacer()

            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text("ODO")
                    .font(.system(size: 22, weight: .medium))
                    .foregroundStyle(.secondary)
                Text("\(odoText(u))\(u.distLabel)")
                    .font(.system(size: 26, weight: .semibold))
                    .monospacedDigit()
            }
        }
    }

    // MARK: Values

    private var pressureLabels: [String] {
        store.snap.tirePressureBar.map { bar in
            guard let bar else { return store.metric ? "–– bar" : "–– psi" }
            return store.metric ? String(format: "%.1f bar", bar) : String(format: "%.0f psi", bar * 14.5038)
        }
    }

    private var tempLabels: [String] {
        store.snap.tireTempC.map { tempText($0) }
    }

    private func tempText(_ c: Double?) -> String {
        guard let c else { return store.metric ? "––°C" : "––°F" }
        return store.metric ? String(format: "%.0f°C", c) : String(format: "%.0f°F", c * 9 / 5 + 32)
    }

    private func odoText(_ u: Units) -> String {
        guard let km = store.snap.odometerKm else { return "––" }
        let v = store.metric ? km : km * 0.621371
        return v.formatted(.number.precision(.fractionLength(0)))
    }
}

// MARK: - Speed dial

struct SpeedDial: View {
    let speed: Double?
    let unit: String
    let gear: String

    var body: some View {
        GeometryReader { geo in
            let d = min(geo.size.width, geo.size.height)
            ZStack {
                Circle()
                    .fill(RadialGradient(colors: [Color.white.opacity(0.06), Color.clear],
                                         center: .center, startRadius: 0, endRadius: d * 0.6))
                Circle()
                    .stroke(Color.white.opacity(0.16), lineWidth: 2)
                    .shadow(color: .white.opacity(0.12), radius: 10)

                VStack(spacing: d * 0.02) {
                    HStack(spacing: d * 0.08) {
                        ForEach(["P", "R", "N", "D"], id: \.self) { g in
                            Text(g)
                                .font(.system(size: d * 0.075, weight: g == gear ? .bold : .medium))
                                .foregroundStyle(g == gear ? Color.white : Color.white.opacity(0.35))
                        }
                    }
                    Text(Fmt.num(speed, 0).replacingOccurrences(of: "––", with: "0"))
                        .font(.system(size: d * 0.36, weight: .regular))
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                        .contentTransition(.numericText())
                        .animation(.easeOut(duration: 0.15), value: speed ?? 0)
                    Text(unit)
                        .font(.system(size: d * 0.08, weight: .regular))
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: d, height: d)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .aspectRatio(1, contentMode: .fit)
        .padding(.vertical, 8)
    }
}

// MARK: - Car with four tire readouts (FL, FR, RL, RR)

struct TireCar: View {
    let labels: [String]

    var body: some View {
        GeometryReader { geo in
            let h = min(geo.size.height * 0.62, 240)
            let w = h * 0.46
            HStack(spacing: 10) {
                VStack(alignment: .trailing) {
                    label(0); Spacer(); label(2)
                }
                CarTopShape()
                    .frame(width: w, height: h)
                VStack(alignment: .leading) {
                    label(1); Spacer(); label(3)
                }
            }
            .frame(height: h * 0.62)
            .padding(.top, h * 0.08)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func label(_ i: Int) -> some View {
        Text(i < labels.count ? labels[i] : "––")
            .font(.system(size: 20, weight: .semibold))
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.6)
            .fixedSize()
    }
}

/// Simple line drawing of a Model 3 seen from above, nose up.
struct CarTopShape: View {
    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            ZStack {
                // tires
                ForEach(0..<4, id: \.self) { i in
                    let x = i % 2 == 0 ? w * 0.02 : w * 0.98
                    let y = i < 2 ? h * 0.27 : h * 0.78
                    RoundedRectangle(cornerRadius: w * 0.05)
                        .fill(Color(white: 0.35))
                        .frame(width: w * 0.13, height: h * 0.15)
                        .position(x: x, y: y)
                }
                // body
                Path { p in
                    p.move(to: CGPoint(x: w * 0.5, y: 0))
                    p.addCurve(to: CGPoint(x: w * 0.93, y: h * 0.12),
                               control1: CGPoint(x: w * 0.78, y: 0),
                               control2: CGPoint(x: w * 0.9, y: h * 0.04))
                    p.addCurve(to: CGPoint(x: w * 0.95, y: h * 0.88),
                               control1: CGPoint(x: w * 1.0, y: h * 0.4),
                               control2: CGPoint(x: w * 1.0, y: h * 0.7))
                    p.addCurve(to: CGPoint(x: w * 0.5, y: h),
                               control1: CGPoint(x: w * 0.92, y: h * 0.97),
                               control2: CGPoint(x: w * 0.75, y: h))
                    p.addCurve(to: CGPoint(x: w * 0.05, y: h * 0.88),
                               control1: CGPoint(x: w * 0.25, y: h),
                               control2: CGPoint(x: w * 0.08, y: h * 0.97))
                    p.addCurve(to: CGPoint(x: w * 0.07, y: h * 0.12),
                               control1: CGPoint(x: 0, y: h * 0.7),
                               control2: CGPoint(x: 0, y: h * 0.4))
                    p.addCurve(to: CGPoint(x: w * 0.5, y: 0),
                               control1: CGPoint(x: w * 0.1, y: h * 0.04),
                               control2: CGPoint(x: w * 0.22, y: 0))
                }
                .fill(Color(white: 0.06))
                carLines(w: w, h: h)
                    .stroke(Color.white.opacity(0.55), lineWidth: 1.2)
                // mirrors
                Capsule().stroke(Color.white.opacity(0.55), lineWidth: 1.2)
                    .frame(width: w * 0.14, height: h * 0.03)
                    .rotationEffect(.degrees(-20))
                    .position(x: -w * 0.02, y: h * 0.36)
                Capsule().stroke(Color.white.opacity(0.55), lineWidth: 1.2)
                    .frame(width: w * 0.14, height: h * 0.03)
                    .rotationEffect(.degrees(20))
                    .position(x: w * 1.02, y: h * 0.36)
            }
        }
    }

    private func carLines(w: CGFloat, h: CGFloat) -> Path {
        Path { p in
            // outline
            p.move(to: CGPoint(x: w * 0.5, y: 0))
            p.addCurve(to: CGPoint(x: w * 0.93, y: h * 0.12),
                       control1: CGPoint(x: w * 0.78, y: 0), control2: CGPoint(x: w * 0.9, y: h * 0.04))
            p.addCurve(to: CGPoint(x: w * 0.95, y: h * 0.88),
                       control1: CGPoint(x: w * 1.0, y: h * 0.4), control2: CGPoint(x: w * 1.0, y: h * 0.7))
            p.addCurve(to: CGPoint(x: w * 0.5, y: h),
                       control1: CGPoint(x: w * 0.92, y: h * 0.97), control2: CGPoint(x: w * 0.75, y: h))
            p.addCurve(to: CGPoint(x: w * 0.05, y: h * 0.88),
                       control1: CGPoint(x: w * 0.25, y: h), control2: CGPoint(x: w * 0.08, y: h * 0.97))
            p.addCurve(to: CGPoint(x: w * 0.07, y: h * 0.12),
                       control1: CGPoint(x: 0, y: h * 0.7), control2: CGPoint(x: 0, y: h * 0.4))
            p.addCurve(to: CGPoint(x: w * 0.5, y: 0),
                       control1: CGPoint(x: w * 0.1, y: h * 0.04), control2: CGPoint(x: w * 0.22, y: 0))

            // windshield
            p.move(to: CGPoint(x: w * 0.18, y: h * 0.36))
            p.addQuadCurve(to: CGPoint(x: w * 0.82, y: h * 0.36), control: CGPoint(x: w * 0.5, y: h * 0.27))
            // glass roof edges
            p.move(to: CGPoint(x: w * 0.18, y: h * 0.36))
            p.addCurve(to: CGPoint(x: w * 0.22, y: h * 0.80),
                       control1: CGPoint(x: w * 0.14, y: h * 0.5), control2: CGPoint(x: w * 0.15, y: h * 0.7))
            p.move(to: CGPoint(x: w * 0.82, y: h * 0.36))
            p.addCurve(to: CGPoint(x: w * 0.78, y: h * 0.80),
                       control1: CGPoint(x: w * 0.86, y: h * 0.5), control2: CGPoint(x: w * 0.85, y: h * 0.7))
            // rear window
            p.move(to: CGPoint(x: w * 0.22, y: h * 0.80))
            p.addQuadCurve(to: CGPoint(x: w * 0.78, y: h * 0.80), control: CGPoint(x: w * 0.5, y: h * 0.86))
            // hood line
            p.move(to: CGPoint(x: w * 0.25, y: h * 0.08))
            p.addQuadCurve(to: CGPoint(x: w * 0.75, y: h * 0.08), control: CGPoint(x: w * 0.5, y: h * 0.04))
        }
    }
}

// MARK: - Small pieces

struct SpeedLimitPill: View {
    let limit: Double?

    var body: some View {
        VStack(spacing: 18) {
            Text(limit.map { String(format: "%.0f", $0) } ?? "––")
                .font(.system(size: 22, weight: .semibold))
                .monospacedDigit()
            Button {
                if let url = URL(string: "maps://") { UIApplication.shared.open(url) }
            } label: {
                Image(systemName: "arrow.right").font(.system(size: 18, weight: .semibold))
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.white)
        .padding(.vertical, 18)
        .frame(width: 64)
        .background(Capsule().fill(Color.black))
        .overlay(Capsule().stroke(Color.white.opacity(0.25), lineWidth: 1.5))
    }
}

struct ConnectionPill: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        Menu {
            Button("Reconnect", systemImage: "arrow.clockwise") { store.reconnect() }
            Toggle("Demo mode", isOn: Binding(get: { store.demoMode }, set: { store.setDemo($0) }))
        } label: {
            HStack(spacing: 10) {
                HStack(spacing: -4) {
                    Circle().fill(Color.red.opacity(0.85)).frame(width: 14, height: 14)
                    Circle().fill(dotColor).frame(width: 14, height: 14)
                }
                Image(systemName: "chevron.down").font(.system(size: 14, weight: .semibold))
                Rectangle().fill(Color.white.opacity(0.2)).frame(width: 1, height: 22)
                Image(systemName: isLive ? "checkmark" : "plus").font(.system(size: 16, weight: .bold))
                Text(label).font(.system(size: 18, weight: .semibold)).lineLimit(1)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 14).padding(.vertical, 8)
            .background(Capsule().fill(isLive ? Color.green.opacity(0.25) : Color(red: 0.4, green: 0.1, blue: 0.12)))
        }
    }

    private var isLive: Bool { store.demoMode || store.status == .streaming }

    private var dotColor: Color {
        switch store.status {
        case .streaming: return .green
        case .connecting: return .yellow
        default: return .gray
        }
    }

    private var label: String {
        if store.demoMode { return "Demo" }
        switch store.status {
        case .streaming: return "Commander"
        case .connecting: return "Connecting"
        default: return "Pair Vehicle"
        }
    }
}

struct PhoneBattery: View {
    @State private var level: Float = UIDevice.current.batteryLevel

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "iphone").font(.system(size: 18))
            Text(level >= 0 ? "\(Int((level * 100).rounded()))" : "––")
                .font(.system(size: 15, weight: .heavy))
                .foregroundStyle(.black)
                .padding(.horizontal, 5).padding(.vertical, 1)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.white))
        }
        .onAppear {
            UIDevice.current.isBatteryMonitoringEnabled = true
            level = UIDevice.current.batteryLevel
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.batteryLevelDidChangeNotification)) { _ in
            level = UIDevice.current.batteryLevel
        }
    }
}

struct MiniBattery: View {
    let percent: Double?

    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.15))
            RoundedRectangle(cornerRadius: 6)
                .fill(fill)
                .frame(width: 70 * CGFloat(min(max((percent ?? 0) / 100, 0), 1)))
        }
        .frame(width: 70, height: 26)
    }

    private var fill: Color {
        guard let p = percent else { return .clear }
        return p < 15 ? .red : (p < 30 ? .orange : .green)
    }
}
