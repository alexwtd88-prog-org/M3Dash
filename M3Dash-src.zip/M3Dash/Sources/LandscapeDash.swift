import SwiftUI
import UIKit

/// Which view the landscape right panel shows. Tap cycles through them.
enum DashPanel: String, CaseIterable {
    case drive, nav, tires, music

    var next: DashPanel {
        let all = DashPanel.allCases
        let i = all.firstIndex(of: self) ?? 0
        return all[(i + 1) % all.count]
    }

    var previous: DashPanel {
        let all = DashPanel.allCases
        let i = all.firstIndex(of: self) ?? 0
        return all[(i - 1 + all.count) % all.count]
    }
}

/// Full-screen, Tesla-style cluster shown when the phone is turned sideways.
struct LandscapeDash: View {
    @EnvironmentObject var store: VehicleStore
    @EnvironmentObject var nav: NavigationModel
    @EnvironmentObject var weather: WeatherService
    @EnvironmentObject var location: LocationService
    @EnvironmentObject var music: MusicModel
    @Environment(\.colorScheme) private var scheme
    @AppStorage("nightDim") private var nightDim = false
    @AppStorage("landscapePanel") private var panelRaw = DashPanel.drive.rawValue
    @AppStorage("hudMode") private var hudMode = false
    @AppStorage("textSize") private var textSizeRaw = TextSizeOption.medium.rawValue
    @AppStorage("theme") private var themeRaw = ThemeMode.dark.rawValue
    @AppStorage("showWeather") private var showWeather = true
    @State private var showSettings = false
    @State private var showSearch = false

    private var scale: CGFloat { (TextSizeOption(rawValue: textSizeRaw) ?? .medium).scale }

    var body: some View {
        Group {
            if hudMode {
                HUDView()
            } else {
                cluster
            }
        }
        .environment(\.dashScale, scale)
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(store)
                .environmentObject(nav)
                .environmentObject(location)
                .environmentObject(music)
        }
        .sheet(isPresented: $showSearch) {
            DestinationSearchSheet()
                .environmentObject(nav)
        }
    }

    private var cluster: some View {
        ZStack {
            DashColors.background(scheme).ignoresSafeArea()

            VStack(spacing: 0) {
                topBar
                    .padding(.top, 6)
                middle
                    .frame(maxHeight: .infinity)
                bottomBar
                    .padding(.bottom, 6)
            }
            .padding(.horizontal, 18)

            if nightDim {
                Color.black.opacity(0.45).ignoresSafeArea().allowsHitTesting(false)
            }
        }
    }

    private var middle: some View {
        let u = Units(metric: store.metric)
        return ZStack {
            GeometryReader { geo in
                let dialSize: CGFloat = min(geo.size.height, geo.size.width * 0.34)
                let side: CGFloat = max(0, (geo.size.width - dialSize - 24) / 2)
                HStack(spacing: 12) {
                    TireCar(labels: pressureLabels, status: store.carStatus)
                        .frame(width: side, height: geo.size.height)
                        .clipped()
                    SpeedDial(speed: u.speed(store.speedMph),
                              unit: u.speedLabel,
                              gear: store.gearLetter,
                              leftTurn: store.turnLeftActive,
                              rightTurn: store.turnRightActive)
                        .frame(width: dialSize, height: geo.size.height)
                    DashRightPanel(panelRaw: $panelRaw,
                                   tempLabels: tempLabels,
                                   onSearch: { showSearch = true })
                        .frame(width: side, height: geo.size.height)
                        .clipped()
                }
            }
            VStack {
                HStack {
                    Spacer()
                    SpeedLimitPill(limit: store.snap.speedLimit)
                }
                Spacer()
            }
        }
    }

    // MARK: Top bar

    private var topBar: some View {
        TimelineView(.periodic(from: .now, by: 1)) { ctx in
            HStack(spacing: 14) {
                Text(ctx.date, format: .dateTime.hour().minute())
                    .font(.system(size: 26 * scale, weight: .semibold))
                    .monospacedDigit()

                temperatures

                if store.status == .connecting {
                    ProgressView()
                }

                Spacer()

                ConnectionPill()

                PhoneBattery()

                topButtons
            }
            .font(.system(size: 22, weight: .semibold))
            .foregroundStyle(.primary)
            .buttonStyle(.plain)
        }
    }

    private var temperatures: some View {
        HStack(spacing: 4) {
            if showWeather, let w = weather.current {
                Image(systemName: w.symbol)
                    .symbolRenderingMode(.multicolor)
            } else {
                Image(systemName: "thermometer.medium")
                    .foregroundStyle(.secondary)
            }
            Text(outsideTempText)
            Text("·").foregroundStyle(.secondary)
            Image(systemName: "car.fill")
            Text(tempText(store.snap.cabinTempC))
        }
        .font(.system(size: 22 * scale, weight: .semibold))
    }

    private var topButtons: some View {
        HStack(spacing: 12) {
            Button {
                let current = ThemeMode(rawValue: themeRaw) ?? .dark
                themeRaw = current.next.rawValue
            } label: {
                Image(systemName: (ThemeMode(rawValue: themeRaw) ?? .dark).symbol)
            }
            .accessibilityLabel("Theme")

            Button { hudMode = true } label: {
                Image(systemName: "arrow.left.and.right.righttriangle.left.righttriangle.right")
            }
            .accessibilityLabel("HUD mode")

            Button {
                store.keepAwake.toggle()
                UIApplication.shared.isIdleTimerDisabled = store.keepAwake
            } label: {
                Image(systemName: store.keepAwake ? "lightbulb.fill" : "lightbulb")
            }

            Button { nightDim.toggle() } label: {
                Image(systemName: nightDim ? "moon.fill" : "moon")
            }

            Button { showSettings = true } label: {
                Image(systemName: "gearshape.fill")
            }
        }
    }

    // MARK: Bottom bar

    private var bottomBar: some View {
        let u = Units(metric: store.metric)
        return HStack(alignment: .firstTextBaseline) {
            HStack(spacing: 10) {
                MiniBattery(percent: store.socPercent)
                Text("\(Fmt.num(store.socPercent, 0))%")
                    + Text(" / ").foregroundColor(.secondary)
                    + Text("\(Fmt.num(u.dist(store.rangeMiles), 0))\(u.distLabel)")
            }
            .font(.system(size: 26 * scale, weight: .semibold))
            .monospacedDigit()

            Spacer()

            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text("ODO")
                    .font(.system(size: 22 * scale, weight: .medium))
                    .foregroundStyle(.secondary)
                Text("\(odoText(u))\(u.distLabel)")
                    .font(.system(size: 26 * scale, weight: .semibold))
                    .monospacedDigit()
            }
        }
    }

    // MARK: Values

    private var outsideTempText: String {
        if let c = store.snap.outsideTempC { return tempText(c) }
        if showWeather, let w = weather.current {
            let c = (w.temperatureF - 32) * 5 / 9
            return tempText(c)
        }
        return tempText(nil)
    }

    private var pressureLabels: [String] {
        store.snap.tirePressureBar.map { bar in
            guard let bar else { return store.metric ? "–– bar" : "–– psi" }
            return store.metric ? String(format: "%.1f bar", bar) : String(format: "%.0f psi", bar * 14.5038)
        }
    }

    private var tempLabels: [String] {
        store.snap.tireTempC.map { tempText($0) }
    }

    private func tempText(_ c: Double?) -> String {
        guard let c else { return store.metric ? "––°C" : "––°F" }
        return store.metric ? String(format: "%.0f°C", c) : String(format: "%.0f°F", c * 9 / 5 + 32)
    }

    private func odoText(_ u: Units) -> String {
        guard let km = store.snap.odometerKm else { return "––" }
        let v = store.metric ? km : km * 0.621371
        return v.formatted(.number.precision(.fractionLength(0)))
    }
}

// MARK: - Right panel (Current Drive → Map/Nav → Tire temps → Music)

struct DashRightPanel: View {
    @Binding var panelRaw: String
    let tempLabels: [String]
    let onSearch: () -> Void

    private var panel: DashPanel { DashPanel(rawValue: panelRaw) ?? .drive }

    var body: some View {
        VStack(spacing: 6) {
            content
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            PanelDots(current: panel, onTap: cycle)
                .gesture(swipe)
        }
        .padding(.trailing, 72)   // room for the speed-limit pill
        .padding(.leading, 8)
        .padding(.vertical, 6)
    }

    @ViewBuilder
    private var content: some View {
        switch panel {
        case .drive:
            CurrentDriveCard(compact: true)
                .contentShape(Rectangle())
                .onTapGesture { cycle() }
                .gesture(swipe)
        case .nav:
            // The map needs its own pans, so swipe on the icon strip below to leave it.
            NavPanel(onSearch: onSearch)
        case .tires:
            TireCar(labels: tempLabels)
                .contentShape(Rectangle())
                .onTapGesture { cycle() }
                .gesture(swipe)
        case .music:
            MusicPanel(compact: true)
                .frame(maxHeight: .infinity, alignment: .center)
                .contentShape(Rectangle())
                .simultaneousGesture(swipe)
        }
    }

    private func cycle() {
        withAnimation(.easeInOut(duration: 0.2)) {
            panelRaw = panel.next.rawValue
        }
    }

    private func goBack() {
        withAnimation(.easeInOut(duration: 0.2)) {
            panelRaw = panel.previous.rawValue
        }
    }

    /// Horizontal swipe: left = next panel, right = previous panel.
    private var swipe: some Gesture {
        DragGesture(minimumDistance: 25)
            .onEnded { value in
                let dx = value.translation.width
                let dy = value.translation.height
                guard abs(dx) > 40, abs(dx) > abs(dy) else { return }
                if dx < 0 { cycle() } else { goBack() }
            }
    }
}

/// Page dots for the right panel; tapping them moves to the next panel.
struct PanelDots: View {
    let current: DashPanel
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 8) {
                ForEach(DashPanel.allCases, id: \.self) { p in
                    Image(systemName: symbol(p))
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(p == current ? Color.primary : Color.secondary.opacity(0.5))
                }
                Image(systemName: "chevron.right")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12).padding(.vertical, 6)
            .background(Capsule().fill(Color.primary.opacity(0.07)))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Next panel")
    }

    private func symbol(_ p: DashPanel) -> String {
        switch p {
        case .drive: return "chart.xyaxis.line"
        case .nav: return "map.fill"
        case .tires: return "thermometer.medium"
        case .music: return "music.note"
        }
    }
}

// MARK: - Speed dial

struct SpeedDial: View {
    let speed: Double?
    let unit: String
    let gear: String
    var leftTurn = false
    var rightTurn = false
    @Environment(\.dashScale) private var scale

    var body: some View {
        GeometryReader { geo in
            let d = min(geo.size.width, geo.size.height)
            ZStack {
                Circle()
                    .fill(RadialGradient(colors: [Color.primary.opacity(0.06), Color.clear],
                                         center: .center, startRadius: 0, endRadius: d * 0.6))
                Circle()
                    .stroke(Color.primary.opacity(0.16), lineWidth: 2)
                    .shadow(color: Color.primary.opacity(0.12), radius: 10)

                // Turn signal arrows at the top corners of the dial.
                VStack {
                    TurnArrows(left: leftTurn, right: rightTurn, size: d * 0.1)
                    Spacer()
                }
                .padding(.horizontal, d * 0.06)
                .padding(.top, d * 0.04)

                VStack(spacing: d * 0.02) {
                    HStack(spacing: d * 0.08) {
                        ForEach(["P", "R", "N", "D"], id: \.self) { g in
                            Text(g)
                                .font(.system(size: d * 0.075 * scale, weight: g == gear ? .bold : .medium))
                                .foregroundStyle(g == gear ? Color.primary : Color.primary.opacity(0.35))
                        }
                    }
                    Text(Fmt.num(speed, 0).replacingOccurrences(of: "––", with: "0"))
                        .font(.system(size: d * 0.36 * scale, weight: .regular))
                        .monospacedDigit()
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                        .contentTransition(.numericText())
                        .animation(.easeOut(duration: 0.15), value: speed ?? 0)
                    Text(unit)
                        .font(.system(size: d * 0.08 * scale, weight: .regular))
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: d, height: d)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .aspectRatio(1, contentMode: .fit)
        .padding(.vertical, 8)
    }
}

// MARK: - Car with four tire readouts (FL, FR, RL, RR)

struct TireCar: View {
    let labels: [String]
    var status: CarIconStatus? = nil
    @Environment(\.dashScale) private var scale

    var body: some View {
        GeometryReader { geo in
            let h = min(geo.size.height * 0.62, geo.size.width * 0.9, 240)
            let w = h * 0.46
            HStack(spacing: 10) {
                VStack(alignment: .trailing) {
                    label(0); Spacer(); label(2)
                }
                ZStack {
                    CarTopShape()
                    if let status {
                        CarStatusOverlay(status: status)
                    }
                }
                .frame(width: w, height: h)
                VStack(alignment: .leading) {
                    label(1); Spacer(); label(3)
                }
            }
            .frame(height: h * 0.62)
            .padding(.top, h * 0.08)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func label(_ i: Int) -> some View {
        Text(i < labels.count ? labels[i] : "––")
            .font(.system(size: 20 * scale, weight: .semibold))
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.5)
    }
}

/// Simple line drawing of a Model 3 seen from above, nose up.
struct CarTopShape: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            ZStack {
                // tires
                ForEach(0..<4, id: \.self) { i in
                    let x = i % 2 == 0 ? w * 0.02 : w * 0.98
                    let y = i < 2 ? h * 0.27 : h * 0.78
                    RoundedRectangle(cornerRadius: w * 0.05)
                        .fill(DashColors.tire(scheme))
                        .frame(width: w * 0.13, height: h * 0.15)
                        .position(x: x, y: y)
                }
                // body
                Path { p in
                    p.move(to: CGPoint(x: w * 0.5, y: 0))
                    p.addCurve(to: CGPoint(x: w * 0.93, y: h * 0.12),
                               control1: CGPoint(x: w * 0.78, y: 0),
                               control2: CGPoint(x: w * 0.9, y: h * 0.04))
                    p.addCurve(to: CGPoint(x: w * 0.95, y: h * 0.88),
                               control1: CGPoint(x: w * 1.0, y: h * 0.4),
                               control2: CGPoint(x: w * 1.0, y: h * 0.7))
                    p.addCurve(to: CGPoint(x: w * 0.5, y: h),
                               control1: CGPoint(x: w * 0.92, y: h * 0.97),
                               control2: CGPoint(x: w * 0.75, y: h))
                    p.addCurve(to: CGPoint(x: w * 0.05, y: h * 0.88),
                               control1: CGPoint(x: w * 0.25, y: h),
                               control2: CGPoint(x: w * 0.08, y: h * 0.97))
                    p.addCurve(to: CGPoint(x: w * 0.07, y: h * 0.12),
                               control1: CGPoint(x: 0, y: h * 0.7),
                               control2: CGPoint(x: 0, y: h * 0.4))
                    p.addCurve(to: CGPoint(x: w * 0.5, y: 0),
                               control1: CGPoint(x: w * 0.1, y: h * 0.04),
                               control2: CGPoint(x: w * 0.22, y: 0))
                }
                .fill(DashColors.carBody(scheme))
                carLines(w: w, h: h)
                    .stroke(Color.primary.opacity(0.55), lineWidth: 1.2)
                // mirrors
                Capsule().stroke(Color.primary.opacity(0.55), lineWidth: 1.2)
                    .frame(width: w * 0.14, height: h * 0.03)
                    .rotationEffect(.degrees(-20))
                    .position(x: -w * 0.02, y: h * 0.36)
                Capsule().stroke(Color.primary.opacity(0.55), lineWidth: 1.2)
                    .frame(width: w * 0.14, height: h * 0.03)
                    .rotationEffect(.degrees(20))
                    .position(x: w * 1.02, y: h * 0.36)
            }
        }
    }

    private func carLines(w: CGFloat, h: CGFloat) -> Path {
        Path { p in
            // outline
            p.move(to: CGPoint(x: w * 0.5, y: 0))
            p.addCurve(to: CGPoint(x: w * 0.93, y: h * 0.12),
                       control1: CGPoint(x: w * 0.78, y: 0), control2: CGPoint(x: w * 0.9, y: h * 0.04))
            p.addCurve(to: CGPoint(x: w * 0.95, y: h * 0.88),
                       control1: CGPoint(x: w * 1.0, y: h * 0.4), control2: CGPoint(x: w * 1.0, y: h * 0.7))
            p.addCurve(to: CGPoint(x: w * 0.5, y: h),
                       control1: CGPoint(x: w * 0.92, y: h * 0.97), control2: CGPoint(x: w * 0.75, y: h))
            p.addCurve(to: CGPoint(x: w * 0.05, y: h * 0.88),
                       control1: CGPoint(x: w * 0.25, y: h), control2: CGPoint(x: w * 0.08, y: h * 0.97))
            p.addCurve(to: CGPoint(x: w * 0.07, y: h * 0.12),
                       control1: CGPoint(x: 0, y: h * 0.7), control2: CGPoint(x: 0, y: h * 0.4))
            p.addCurve(to: CGPoint(x: w * 0.5, y: 0),
                       control1: CGPoint(x: w * 0.1, y: h * 0.04), control2: CGPoint(x: w * 0.22, y: 0))

            // windshield
            p.move(to: CGPoint(x: w * 0.18, y: h * 0.36))
            p.addQuadCurve(to: CGPoint(x: w * 0.82, y: h * 0.36), control: CGPoint(x: w * 0.5, y: h * 0.27))
            // glass roof edges
            p.move(to: CGPoint(x: w * 0.18, y: h * 0.36))
            p.addCurve(to: CGPoint(x: w * 0.22, y: h * 0.80),
                       control1: CGPoint(x: w * 0.14, y: h * 0.5), control2: CGPoint(x: w * 0.15, y: h * 0.7))
            p.move(to: CGPoint(x: w * 0.82, y: h * 0.36))
            p.addCurve(to: CGPoint(x: w * 0.78, y: h * 0.80),
                       control1: CGPoint(x: w * 0.86, y: h * 0.5), control2: CGPoint(x: w * 0.85, y: h * 0.7))
            // rear window
            p.move(to: CGPoint(x: w * 0.22, y: h * 0.80))
            p.addQuadCurve(to: CGPoint(x: w * 0.78, y: h * 0.80), control: CGPoint(x: w * 0.5, y: h * 0.86))
            // hood line
            p.move(to: CGPoint(x: w * 0.25, y: h * 0.08))
            p.addQuadCurve(to: CGPoint(x: w * 0.75, y: h * 0.08), control: CGPoint(x: w * 0.5, y: h * 0.04))
        }
    }
}

// MARK: - Small pieces

struct SpeedLimitPill: View {
    let limit: Double?

    var body: some View {
        VStack(spacing: 18) {
            Text(limit.map { String(format: "%.0f", $0) } ?? "––")
                .font(.system(size: 22, weight: .semibold))
                .monospacedDigit()
            Button {
                if let url = URL(string: "maps://") { UIApplication.shared.open(url) }
            } label: {
                Image(systemName: "arrow.right").font(.system(size: 18, weight: .semibold))
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.primary)
        .padding(.vertical, 18)
        .frame(width: 64)
        .background(Capsule().fill(Color(uiColor: .systemBackground)))
        .overlay(Capsule().stroke(Color.primary.opacity(0.25), lineWidth: 1.5))
    }
}

struct ConnectionPill: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        Menu {
            Button("Reconnect", systemImage: "arrow.clockwise") { store.reconnect() }
            Toggle("Demo mode", isOn: Binding(get: { store.demoMode }, set: { store.setDemo($0) }))
        } label: {
            HStack(spacing: 10) {
                HStack(spacing: -4) {
                    Circle().fill(Color.red.opacity(0.85)).frame(width: 14, height: 14)
                    Circle().fill(dotColor).frame(width: 14, height: 14)
                }
                Image(systemName: "chevron.down").font(.system(size: 14, weight: .semibold))
                Rectangle().fill(Color.white.opacity(0.35)).frame(width: 1, height: 22)
                Image(systemName: isLive ? "checkmark" : "plus").font(.system(size: 16, weight: .bold))
                Text(label).font(.system(size: 16, weight: .semibold)).lineLimit(1).fixedSize()
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(Capsule().fill(isLive ? Color(red: 0.1, green: 0.42, blue: 0.2) : Color(red: 0.4, green: 0.1, blue: 0.12)))
        }
    }

    private var isLive: Bool { store.demoMode || store.status == .streaming }

    private var dotColor: Color {
        switch store.status {
        case .streaming: return .green
        case .connecting: return .yellow
        default: return .gray
        }
    }

    private var label: String {
        if store.demoMode { return "Demo" }
        switch store.status {
        case .streaming: return "Commander"
        case .connecting: return "Connecting"
        default: return "Pair Vehicle"
        }
    }
}

struct PhoneBattery: View {
    @State private var level: Float = UIDevice.current.batteryLevel

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "iphone").font(.system(size: 18))
            Text(level >= 0 ? "\(Int((level * 100).rounded()))" : "––")
                .font(.system(size: 15, weight: .heavy))
                .foregroundStyle(Color(uiColor: .systemBackground))
                .padding(.horizontal, 5).padding(.vertical, 1)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.primary))
        }
        .onAppear {
            UIDevice.current.isBatteryMonitoringEnabled = true
            level = UIDevice.current.batteryLevel
        }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.batteryLevelDidChangeNotification)) { _ in
            level = UIDevice.current.batteryLevel
        }
    }
}

struct MiniBattery: View {
    let percent: Double?

    var body: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 6).fill(Color.primary.opacity(0.15))
            RoundedRectangle(cornerRadius: 6)
                .fill(fill)
                .frame(width: 70 * CGFloat(min(max((percent ?? 0) / 100, 0), 1)))
        }
        .frame(width: 70, height: 26)
    }

    private var fill: Color {
        guard let p = percent else { return .clear }
        return p < 15 ? .red : (p < 30 ? .orange : .green)
    }
}
