import SwiftUI

// MARK: - Drive

struct DriveView: View {
    @EnvironmentObject var store: VehicleStore
    @Environment(\.verticalSizeClass) var vSize

    var body: some View {
        let u = Units(metric: store.metric)
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    ConnectionBadge()
                    Spacer()
                    Text(store.gearLetter)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .padding(.horizontal, 12).padding(.vertical, 4)
                        .background(Capsule().fill(Color.white.opacity(0.1)))
                }

                if vSize == .compact {
                    HStack(spacing: 24) { speedBlock(u); powerBlock }
                } else {
                    speedBlock(u)
                    powerBlock
                }

                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .firstTextBaseline) {
                        Text("\(Fmt.num(store.socPercent, 0))%")
                            .font(.system(size: 34, weight: .semibold, design: .rounded)).monospacedDigit()
                        Spacer()
                        Text("\(Fmt.num(u.dist(store.rangeMiles), 0)) \(u.distLabel)")
                            .font(.system(size: 28, weight: .medium, design: .rounded)).monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    BatteryGauge(percent: store.socPercent)
                }

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    StatTile(title: "Front motor", value: Fmt.num(store.snap.frontPowerKW, 0), unit: "kW")
                    StatTile(title: "Rear motor", value: Fmt.num(store.snap.rearPowerKW, 0), unit: "kW")
                    StatTile(title: "Pack voltage", value: Fmt.num(store.snap.packVoltage, 1), unit: "V")
                    StatTile(title: "Pack current", value: Fmt.num(store.snap.packCurrent, 0), unit: "A")
                    StatTile(title: "Battery temp", value: tempString, unit: store.metric ? "°C" : "°F")
                    StatTile(title: "Drive Wh/\(u.distLabel)", value: Fmt.num(u.eff(store.drive?.whPerMile), 0), unit: "")
                    StatTile(title: "0–60 last", value: Fmt.num(store.lastZeroToSixty, 2), unit: "s")
                    StatTile(title: "0–60 best", value: Fmt.num(store.bestZeroToSixty, 2), unit: "s", tint: .yellow)
                }
            }
            .padding()
        }
    }

    private func speedBlock(_ u: Units) -> some View {
        VStack(spacing: 0) {
            Text(Fmt.num(u.speed(store.speedMph), 0))
                .font(.system(size: 120, weight: .bold, design: .rounded))
                .monospacedDigit()
                .minimumScaleFactor(0.5)
                .lineLimit(1)
                .contentTransition(.numericText())
            Text(u.speedLabel).font(.title3).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var powerBlock: some View {
        let kw = store.batteryPowerKW ?? 0
        return VStack(spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(Fmt.num(store.batteryPowerKW, 0))
                    .font(.system(size: 44, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(kw < 0 ? .green : .white)
                Text("kW").foregroundStyle(.secondary)
            }
            PowerBar(kw: kw)
            HStack {
                Text("Regen").font(.caption2).foregroundStyle(.green)
                Spacer()
                Text("Power").font(.caption2).foregroundStyle(.red)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var tempString: String {
        guard let lo = store.snap.packTempMinC, let hi = store.snap.packTempMaxC else { return "––" }
        let avg = (lo + hi) / 2
        return Fmt.num(store.metric ? avg : avg * 9 / 5 + 32, 0)
    }
}

// MARK: - Charge

struct ChargeView: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        let u = Units(metric: store.metric)
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HStack { ConnectionBadge(); Spacer() }
                    VStack(spacing: 4) {
                        Text(store.isCharging ? (store.isDCFast ? "Supercharging" : "Charging") : statusText)
                            .font(.headline)
                            .foregroundStyle(store.isCharging ? .green : .secondary)
                        HStack(alignment: .firstTextBaseline, spacing: 4) {
                            Text(Fmt.num(store.chargePowerKW, store.isDCFast ? 0 : 1))
                                .font(.system(size: 96, weight: .bold, design: .rounded))
                                .monospacedDigit()
                                .minimumScaleFactor(0.5)
                            Text("kW").font(.title2).foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity)

                    BatteryGauge(percent: store.socPercent)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatTile(title: "Battery", value: Fmt.num(store.socPercent, 1), unit: "%")
                        StatTile(title: "Range", value: Fmt.num(u.dist(store.rangeMiles), 0), unit: u.distLabel)
                        StatTile(title: "Adding", value: Fmt.num(u.dist(store.milesPerHourAdded), 0), unit: "\(u.distLabel)/hr", tint: .green)
                        StatTile(title: "Time to full", value: Fmt.duration(minutes: store.minutesToFull))
                        StatTile(title: "Added this session", value: Fmt.num(store.charge?.kWhAdded, 2), unit: "kWh")
                        StatTile(title: "Range added", value: Fmt.num(u.dist(store.charge?.milesAdded), 0), unit: u.distLabel)
                        StatTile(title: "Session peak", value: Fmt.num(store.charge?.peakKW, 0), unit: "kW")
                        StatTile(title: "Session time", value: store.charge.map { Fmt.duration(seconds: $0.end.timeIntervalSince($0.start)) } ?? "––")
                        StatTile(title: "AC line", value: acLine)
                        StatTile(title: "Pack", value: "\(Fmt.num(store.snap.packVoltage, 0)) V")
                    }

                    if !store.charges.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Recent charging").font(.headline)
                            ForEach(store.charges.prefix(10)) { c in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(c.start, style: .date).font(.subheadline)
                                        Text("\(Fmt.num(c.startSOC, 0))% → \(Fmt.num(c.endSOC, 0))%")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    VStack(alignment: .trailing) {
                                        Text("\(Fmt.num(c.kWhAdded, 1)) kWh").monospacedDigit()
                                        Text("peak \(Fmt.num(c.peakKW, 0)) kW").font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                                .padding(12)
                                .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06)))
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Charging")
        }
    }

    private var statusText: String {
        switch store.snap.uiChargeStatus {
        case 4: return "Charge complete"
        case 5: return "Charging stopped"
        case 2: return "Starting…"
        default: return store.snap.cablePresent == true ? "Plugged in" : "Not charging"
        }
    }

    private var acLine: String {
        guard let v = store.snap.acLineVoltage, let a = store.snap.acLineCurrent, v > 50 else { return "––" }
        return "\(Fmt.num(v, 0))V \(Fmt.num(a, 0))A"
    }
}

// MARK: - Trips / driving stats

struct TripsView: View {
    @EnvironmentObject var store: VehicleStore
    @State private var confirmReset = false

    var body: some View {
        let u = Units(metric: store.metric)
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    section("Current drive", trip: store.drive, u: u)
                    section("Trip A (since reset)", trip: store.tripA, u: u)
                    Button("Reset Trip A", role: .destructive) { confirmReset = true }
                        .buttonStyle(.bordered)

                    if !store.trips.isEmpty {
                        Text("Recent drives").font(.headline)
                        ForEach(store.trips.prefix(20)) { t in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(t.start, format: .dateTime.month().day().hour().minute())
                                        .font(.subheadline)
                                    Text("\(Fmt.duration(seconds: t.drivingSeconds)) · max \(Fmt.num(u.speed(t.maxMph), 0)) \(u.speedLabel)")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                VStack(alignment: .trailing) {
                                    Text("\(Fmt.num(u.dist(t.miles), 1)) \(u.distLabel)").monospacedDigit()
                                    Text("\(Fmt.num(u.eff(t.whPerMile), 0)) \(u.effLabel)").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06)))
                        }
                    }
                    if let odo = store.snap.odometerKm {
                        Text("Odometer \(Fmt.num(u.dist(odo * 0.621371), 0)) \(u.distLabel)")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .padding()
            }
            .navigationTitle("Driving stats")
            .confirmationDialog("Reset Trip A?", isPresented: $confirmReset) {
                Button("Reset", role: .destructive) { store.resetTripA() }
            }
        }
    }

    @ViewBuilder
    private func section(_ title: String, trip: TripRecord?, u: Units) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                StatTile(title: "Distance", value: Fmt.num(u.dist(trip?.miles), 1), unit: u.distLabel)
                StatTile(title: "Efficiency", value: Fmt.num(u.eff(trip?.whPerMile), 0), unit: u.effLabel)
                StatTile(title: "Energy used", value: Fmt.num(trip?.kWh, 2), unit: "kWh")
                StatTile(title: "Avg speed", value: Fmt.num(u.speed(trip?.avgMph), 0), unit: u.speedLabel)
                StatTile(title: "Peak power", value: Fmt.num(trip?.peakKW, 0), unit: "kW", tint: .red)
                StatTile(title: "Peak regen", value: Fmt.num(trip?.peakRegenKW, 0), unit: "kW", tint: .green)
                StatTile(title: "Top speed", value: Fmt.num(u.speed(trip?.maxMph), 0), unit: u.speedLabel)
                StatTile(title: "Drive time", value: trip.map { Fmt.duration(seconds: $0.drivingSeconds) } ?? "––")
            }
        }
    }
}

// MARK: - Settings

struct SettingsView: View {
    @EnvironmentObject var store: VehicleStore
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    LabeledContent("Status") { ConnectionBadge() }
                    TextField("Commander IP", text: $store.host)
                        .keyboardType(.numbersAndPunctuation)
                        .autocorrectionDisabled()
                    TextField("Port", value: $store.port, format: .number.grouping(.never))
                        .keyboardType(.numberPad)
                    Button("Reconnect") { store.reconnect() }
                } header: {
                    Text("S3XY Commander")
                } footer: {
                    Text("In the S3XY app, turn on Wi-Fi in the Commander's settings, then join its Wi-Fi network on this iPhone. Only one app can use the Commander's Wi-Fi at a time, so close Scan My Tesla first.")
                }

                Section("Display") {
                    Toggle("Metric units", isOn: $store.metric)
                    Toggle("Keep screen awake", isOn: $store.keepAwake)
                        .onChange(of: store.keepAwake) { _, v in UIApplication.shared.isIdleTimerDisabled = v }
                    Toggle("Demo mode", isOn: Binding(get: { store.demoMode }, set: { store.setDemo($0) }))
                }

                Section("Diagnostics") {
                    LabeledContent("Frames / sec", value: "\(store.framesPerSecond)")
                    LabeledContent("Signals seen", value: "\(store.seenIDs.count) of \(CANDecoder.subscribedIDs.count)")
                    let missing = CANDecoder.subscribedIDs.filter { !store.seenIDs.contains($0) }
                    if !missing.isEmpty && store.status == .streaming {
                        Text("Missing: " + missing.map { String(format: "0x%03X", $0) }.joined(separator: ", "))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button("End current drive") { store.endDriveNow() }
                    Button("Clear drive & charge history", role: .destructive) { confirmClear = true }
                }
            }
            .navigationTitle("Settings")
            .confirmationDialog("Clear all history?", isPresented: $confirmClear) {
                Button("Clear", role: .destructive) { store.clearHistory() }
            }
        }
    }
}
