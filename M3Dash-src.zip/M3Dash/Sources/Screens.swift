import SwiftUI
import UniformTypeIdentifiers

// MARK: - Drive

struct DriveView: View {
    @EnvironmentObject var store: VehicleStore
    @Environment(\.verticalSizeClass) var vSize

    var body: some View {
        let u = Units(metric: store.metric)
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    ConnectionBadge()
                    Spacer()
                    Text(store.gearLetter)
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .padding(.horizontal, 12).padding(.vertical, 4)
                        .background(Capsule().fill(Color.primary.opacity(0.1)))
                }

                if vSize == .compact {
                    HStack(spacing: 24) { speedBlock(u); powerBlock }
                } else {
                    speedBlock(u)
                    powerBlock
                }

                CarStatusStrip()

                CurrentDriveCard()

                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .firstTextBaseline) {
                        Text("\(Fmt.num(store.socPercent, 0))%")
                            .font(.system(size: 34, weight: .semibold, design: .rounded)).monospacedDigit()
                        Spacer()
                        Text("\(Fmt.num(u.dist(store.rangeMiles), 0)) \(u.distLabel)")
                            .font(.system(size: 28, weight: .medium, design: .rounded)).monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    BatteryGauge(percent: store.socPercent)
                }

                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    StatTile(title: "Front motor", value: Fmt.num(store.snap.frontPowerKW, 0), unit: "kW")
                    StatTile(title: "Rear motor", value: Fmt.num(store.snap.rearPowerKW, 0), unit: "kW")
                    StatTile(title: "Pack voltage", value: Fmt.num(store.snap.packVoltage, 1), unit: "V")
                    StatTile(title: "Pack current", value: Fmt.num(store.snap.packCurrent, 0), unit: "A")
                    StatTile(title: "Battery temp", value: tempString, unit: store.metric ? "°C" : "°F")
                    StatTile(title: "Drive Wh/\(u.distLabel)", value: Fmt.num(u.eff(store.drive?.whPerMile), 0), unit: "")
                    StatTile(title: "0–60 last", value: Fmt.num(store.lastZeroToSixty, 2), unit: "s")
                    StatTile(title: "0–60 best", value: Fmt.num(store.bestZeroToSixty, 2), unit: "s", tint: .yellow)
                }
            }
            .padding()
        }
    }

    private func speedBlock(_ u: Units) -> some View {
        VStack(spacing: 0) {
            Text(Fmt.num(u.speed(store.speedMph), 0))
                .font(.system(size: 120, weight: .bold, design: .rounded))
                .monospacedDigit()
                .minimumScaleFactor(0.5)
                .lineLimit(1)
                .contentTransition(.numericText())
            Text(u.speedLabel).font(.title3).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var powerBlock: some View {
        let kw = store.batteryPowerKW ?? 0
        return VStack(spacing: 8) {
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(Fmt.num(store.batteryPowerKW, 0))
                    .font(.system(size: 44, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(kw < 0 ? Color.green : Color.primary)
                Text("kW").foregroundStyle(.secondary)
            }
            PowerBar(kw: kw)
            HStack {
                Text("Regen").font(.caption2).foregroundStyle(.green)
                Spacer()
                Text("Power").font(.caption2).foregroundStyle(.red)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var tempString: String {
        guard let lo = store.snap.packTempMinC, let hi = store.snap.packTempMaxC else { return "––" }
        let avg = (lo + hi) / 2
        return Fmt.num(store.metric ? avg : avg * 9 / 5 + 32, 0)
    }
}

// MARK: - Charge

struct ChargeView: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        let u = Units(metric: store.metric)
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    HStack { ConnectionBadge(); Spacer() }
                    VStack(spacing: 4) {
                        Text(store.isCharging ? (store.isDCFast ? "Supercharging" : "Charging") : statusText)
                            .font(.headline)
                            .foregroundStyle(store.isCharging ? .green : .secondary)
                        HStack(alignment: .firstTextBaseline, spacing: 4) {
                            Text(Fmt.num(store.chargePowerKW, store.isDCFast ? 0 : 1))
                                .font(.system(size: 96, weight: .bold, design: .rounded))
                                .monospacedDigit()
                                .minimumScaleFactor(0.5)
                            Text("kW").font(.title2).foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity)

                    BatteryGauge(percent: store.socPercent)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatTile(title: "Battery", value: Fmt.num(store.socPercent, 1), unit: "%")
                        StatTile(title: "Range", value: Fmt.num(u.dist(store.rangeMiles), 0), unit: u.distLabel)
                        StatTile(title: "Adding", value: Fmt.num(u.dist(store.milesPerHourAdded), 0), unit: "\(u.distLabel)/hr", tint: .green)
                        StatTile(title: "Time to full", value: Fmt.duration(minutes: store.minutesToFull))
                        StatTile(title: "Added this session", value: Fmt.num(store.charge?.kWhAdded, 2), unit: "kWh")
                        StatTile(title: "Range added", value: Fmt.num(u.dist(store.charge?.milesAdded), 0), unit: u.distLabel)
                        StatTile(title: "Session peak", value: Fmt.num(store.charge?.peakKW, 0), unit: "kW")
                        StatTile(title: "Session time", value: store.charge.map { Fmt.duration(seconds: $0.end.timeIntervalSince($0.start)) } ?? "––")
                        StatTile(title: "AC line", value: acLine)
                        StatTile(title: "Pack", value: "\(Fmt.num(store.snap.packVoltage, 0)) V")
                    }

                    if !store.charges.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Recent charging").font(.headline)
                            ForEach(store.charges.prefix(10)) { c in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(c.start, style: .date).font(.subheadline)
                                        Text("\(Fmt.num(c.startSOC, 0))% → \(Fmt.num(c.endSOC, 0))%")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    VStack(alignment: .trailing) {
                                        Text("\(Fmt.num(c.kWhAdded, 1)) kWh").monospacedDigit()
                                        Text("peak \(Fmt.num(c.peakKW, 0)) kW").font(.caption).foregroundStyle(.secondary)
                                    }
                                }
                                .padding(12)
                                .background(RoundedRectangle(cornerRadius: 12).fill(Color.primary.opacity(0.06)))
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Charging")
        }
    }

    private var statusText: String {
        switch store.snap.uiChargeStatus {
        case 4: return "Charge complete"
        case 5: return "Charging stopped"
        case 2: return "Starting…"
        default: return store.snap.cablePresent == true ? "Plugged in" : "Not charging"
        }
    }

    private var acLine: String {
        guard let v = store.snap.acLineVoltage, let a = store.snap.acLineCurrent, v > 50 else { return "––" }
        return "\(Fmt.num(v, 0))V \(Fmt.num(a, 0))A"
    }
}

// MARK: - Trips / driving stats

struct TripsView: View {
    @EnvironmentObject var store: VehicleStore
    @State private var confirmReset = false
    @State private var showImporter = false
    @State private var importMessage: String?

    var body: some View {
        let u = Units(metric: store.metric)
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    section("Current drive", trip: store.drive, u: u)
                    section("Trip A (since reset)", trip: store.tripA, u: u)
                    Button("Reset Trip A", role: .destructive) { confirmReset = true }
                        .buttonStyle(.bordered)

                    JourneyFootprints()
                    if let odo = store.snap.odometerKm {
                        Text("Odometer \(Fmt.num(u.dist(odo * 0.621371), 0)) \(u.distLabel)")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .padding()
            }
            .navigationTitle("Driving stats")
            .confirmationDialog("Reset Trip A?", isPresented: $confirmReset) {
                Button("Reset", role: .destructive) { store.resetTripA() }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    ShareLink(item: TripArchive(trips: store.trips),
                              preview: SharePreview("M3 Dash trip history")) {
                        Label("Export trips", systemImage: "square.and.arrow.up")
                    }
                    .disabled(store.trips.isEmpty)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showImporter = true
                    } label: {
                        Label("Import trips", systemImage: "square.and.arrow.down")
                    }
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                handleImport(result)
            }
            .alert("Import trips",
                   isPresented: Binding(get: { importMessage != nil }, set: { if !$0 { importMessage = nil } })) {
                Button("OK", role: .cancel) { importMessage = nil }
            } message: {
                Text(importMessage ?? "")
            }
        }
    }

    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .success(let url):
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            do {
                let data = try Data(contentsOf: url)
                let added = try store.importTrips(from: data)
                importMessage = added == 1 ? "Added 1 drive." : "Added \(added) drives."
            } catch {
                importMessage = "That file isn't an M3 Dash trip export."
            }
        case .failure:
            importMessage = "Couldn't open that file."
        }
    }

    @ViewBuilder
    private func section(_ title: String, trip: TripRecord?, u: Units) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                StatTile(title: "Distance", value: Fmt.num(u.dist(trip?.miles), 1), unit: u.distLabel)
                StatTile(title: "Efficiency", value: Fmt.num(u.eff(trip?.whPerMile), 0), unit: u.effLabel)
                StatTile(title: "Energy used", value: Fmt.num(trip?.kWh, 2), unit: "kWh")
                StatTile(title: "Avg speed", value: Fmt.num(u.speed(trip?.avgMph), 0), unit: u.speedLabel)
                StatTile(title: "Peak power", value: Fmt.num(trip?.peakKW, 0), unit: "kW", tint: .red)
                StatTile(title: "Peak regen", value: Fmt.num(trip?.peakRegenKW, 0), unit: "kW", tint: .green)
                StatTile(title: "Top speed", value: Fmt.num(u.speed(trip?.maxMph), 0), unit: u.speedLabel)
                StatTile(title: "Drive time", value: trip.map { Fmt.duration(seconds: $0.drivingSeconds) } ?? "––")
            }
        }
    }
}

// MARK: - Settings

struct SettingsView: View {
    @EnvironmentObject var store: VehicleStore
    @State private var confirmClear = false
    @AppStorage("theme") private var theme = ThemeMode.dark.rawValue
    @AppStorage("textSize") private var textSize = TextSizeOption.medium.rawValue
    @AppStorage("hudMode") private var hudMode = false
    @AppStorage("navVoice") private var navVoice = false
    @AppStorage("navAvoidHighways") private var avoidHighways = false
    @AppStorage("navAvoidTolls") private var avoidTolls = false
    @AppStorage("mapHeadingUp") private var headingUp = true
    @AppStorage("launchEffect") private var launchEffect = true
    @AppStorage("launchSensitivity") private var launchSensitivity = 1
    @AppStorage("showWeather") private var showWeather = true
    @AppStorage("barClock") private var barClock = false
    @AppStorage("showSpeedLimit") private var showSpeedLimit = false
    @AppStorage("barTemps") private var barTemps = false
    @AppStorage("barConnection") private var barConnection = false
    @AppStorage("barPhoneBattery") private var barPhoneBattery = false
    @AppStorage("barButtons") private var barButtons = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    LabeledContent("Status") { ConnectionBadge() }
                    TextField("Commander IP", text: $store.host)
                        .keyboardType(.numbersAndPunctuation)
                        .autocorrectionDisabled()
                    TextField("Port", value: $store.port, format: .number.grouping(.never))
                        .keyboardType(.numberPad)
                    Button("Reconnect") { store.reconnect() }
                } header: {
                    Text("S3XY Commander")
                } footer: {
                    Text("In the S3XY app, turn on Wi-Fi in the Commander's settings, then join its Wi-Fi network on this iPhone. Only one app can use the Commander's Wi-Fi at a time, so close Scan My Tesla first.")
                }

                Section("Display") {
                    Toggle("Metric units", isOn: $store.metric)
                    Toggle("Keep screen awake", isOn: $store.keepAwake)
                        .onChange(of: store.keepAwake) { _, v in UIApplication.shared.isIdleTimerDisabled = v }
                    Toggle("Demo mode", isOn: Binding(get: { store.demoMode }, set: { store.setDemo($0) }))
                }

                appearanceSections

                featureSections

                Section("Diagnostics") {
                    LabeledContent("Frames / sec", value: "\(store.framesPerSecond)")
                    LabeledContent("Signals seen", value: "\(store.seenIDs.count) of \(CANDecoder.subscribedIDs.count)")
                    NavigationLink("Raw data (send me a screenshot)") { RawDataView() }
                    let missing = CANDecoder.subscribedIDs.filter { !store.seenIDs.contains($0) }
                    if !missing.isEmpty && store.status == .streaming {
                        Text("Missing: " + missing.map { String(format: "0x%03X", $0) }.joined(separator: ", "))
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                Section {
                    Button("End current drive") { store.endDriveNow() }
                    Button("Clear drive & charge history", role: .destructive) { confirmClear = true }
                }
            }
            .navigationTitle("Settings")
            .confirmationDialog("Clear all history?", isPresented: $confirmClear) {
                Button("Clear", role: .destructive) { store.clearHistory() }
            }
        }
    }

    private var appearanceSections: some View {
        Group {
            Section {
                Picker("Theme", selection: $theme) {
                    ForEach(ThemeMode.allCases) { m in
                        Text(m.title).tag(m.rawValue)
                    }
                }
                .pickerStyle(.segmented)
            } header: {
                Text("Theme")
            } footer: {
                Text("Auto is dark from sunset to sunrise at your location, or 7 pm to 7 am when location is off.")
            }

            Section {
                Picker("Text size", selection: $textSize) {
                    ForEach(TextSizeOption.allCases) { o in
                        Text(o.title).tag(o.rawValue)
                    }
                }
                .pickerStyle(.segmented)
            } header: {
                Text("Text size")
            } footer: {
                Text("Scales the text on the landscape dashboard.")
            }

            Section {
                Toggle("Clock", isOn: $barClock)
                Toggle("Outside & cabin temp", isOn: $barTemps)
                Toggle("Commander status", isOn: $barConnection)
                Toggle("Phone battery", isOn: $barPhoneBattery)
                Toggle("Speed limit sign", isOn: $showSpeedLimit)
                Toggle("Quick buttons (theme, HUD, screen awake, dim)", isOn: $barButtons)
            } header: {
                Text("Dashboard top bar")
            } footer: {
                Text("Only the Settings button shows by default. Commander status still pops up on its own if the car isn't connected.")
            }

            Section {
                Toggle("HUD mode", isOn: $hudMode)
            } header: {
                Text("HUD")
            } footer: {
                Text("Turn the phone sideways to get a mirrored, black-background view (speed, gear, next turn, speed limit) for reflecting off the windshield at night. Double-tap it to exit.")
            }

            Section {
                Toggle("Voice guidance", isOn: $navVoice)
                Toggle("Heading up (off = north up)", isOn: $headingUp)
                Toggle("Avoid highways", isOn: $avoidHighways)
                Toggle("Avoid tolls", isOn: $avoidTolls)
            } header: {
                Text("Map & navigation")
            } footer: {
                Text("Map tiles, search, and directions use cellular data, since the Commander's Wi-Fi has no internet. Location is only used while M3 Dash is open.")
            }
        }
    }

    private var featureSections: some View {
        Group {
            Section {
                Toggle("Show outside weather", isOn: $showWeather)
            } header: {
                Text("Weather")
            } footer: {
                Text("Current conditions from Open-Meteo, refreshed every 15 minutes using your location.")
            }

            Section {
                Toggle("Launch effect", isOn: $launchEffect)
                Picker("Sensitivity", selection: $launchSensitivity) {
                    Text("Low").tag(0)
                    Text("Medium").tag(1)
                    Text("High").tag(2)
                }
                .pickerStyle(.segmented)
                .disabled(!launchEffect)
            } header: {
                Text("Toybox")
            } footer: {
                Text("A quick speed-streak burst when you floor it (pedal over 80% and a fast speed gain). High triggers most easily.")
            }

            Section {
                LabeledContent("Source", value: "Apple Music")
            } header: {
                Text("Music")
            } footer: {
                Text("The music panel shows and controls what the Music app is playing. Spotify can't be read without its own SDK, so it isn't supported.")
            }

            CarStatusDiagnostics()
        }
    }
}

/// Settings rows showing whether the car-icon signals are arriving.
struct CarStatusDiagnostics: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        Section {
            LabeledContent("Turn signals", value: turnText)
            LabeledContent("Blind spot", value: blindText)
            LabeledContent("Brake lights", value: brakeText)
            LabeledContent("Lights", value: lightsText)
            LabeledContent("Doors", value: doorsText)
        } header: {
            Text("Car status")
        } footer: {
            Text("Blind spot (0x399) is on the chassis bus and may not reach the Commander.")
        }
    }

    private var turnText: String {
        guard store.snap.turnSignalLeft != nil else { return "No data (0x3F5)" }
        let l = store.turnLeftActive ? "on" : "off"
        let r = store.turnRightActive ? "on" : "off"
        return "L \(l) · R \(r)"
    }

    private var blindText: String {
        guard store.snap.blindSpotLeft != nil else { return "No data (0x399)" }
        return "L \(store.snap.blindSpotLeftLevel) · R \(store.snap.blindSpotRightLevel)"
    }

    private var brakeText: String {
        if store.snap.brakeLight == nil && store.snap.brakePedal == nil { return "No data (0x3E2/0x118)" }
        return store.snap.brakeOn ? "On" : "Off"
    }

    private var lightsText: String {
        guard store.snap.lowBeamLeft != nil else { return "No data (0x3F5)" }
        if store.snap.highBeamOn { return "High beam" }
        return store.snap.lowBeamOn ? "Low beam" : "Off"
    }

    private var doorsText: String {
        if store.snap.latchFL == nil && store.snap.latchFR == nil { return "No data (0x102/0x103)" }
        return store.snap.doorsOpen.contains(true) ? "Open" : "Closed"
    }
}


/// Raw CAN bytes for the signals still being calibrated (battery %, tire pressure).
struct RawDataView: View {
    @EnvironmentObject var store: VehicleStore

    private let watched: [UInt32] = [0x399, 0x219, 0x292, 0x33A, 0x352, 0x20C, 0x243]

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            List {
                Section("FSD / Autopilot") {
                    LabeledContent("DAS_autopilotState (0x399)", value: store.snap.autopilotState.map { "\($0)" } ?? "––")
                    LabeledContent("Engaged", value: store.autopilotActive ? "Yes" : "No")
                }
                Section("Battery % candidates") {
                    LabeledContent("UI_SOC (0x33A)", value: Fmt.num(store.snap.uiSOC, 1))
                    LabeledContent("UI_uSOE (0x33A)", value: Fmt.num(store.snap.uiUSOE, 1))
                    LabeledContent("SOC UI (0x292)", value: Fmt.num(store.snap.socUI, 1))
                    LabeledContent("SOC avg (0x292)", value: Fmt.num(store.snap.socAvg, 1))
                    LabeledContent("Energy left / full", value: "\(Fmt.num(store.snap.nominalRemainingKWh, 1)) / \(Fmt.num(store.snap.nominalFullPackKWh, 1)) kWh")
                }
                Section {
                    ForEach(rows, id: \.0) { row in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(row.0).font(.caption.weight(.semibold))
                            Text(row.1).font(.system(.caption, design: .monospaced))
                        }
                    }
                } header: {
                    Text("Raw frames (bus:ID)")
                } footer: {
                    Text("Take a screenshot of this screen with the Tesla tire screen in view, and send it to Hark.")
                }
            }
        }
        .navigationTitle("Raw data")
    }

    private var rows: [(String, String)] {
        let keys = store.rawFrames.keys.filter { key in
            watched.contains { id in key.contains(":" + String(format: "%03X", id)) }
        }.sorted()
        return keys.map { key in
            let bytes = store.rawFrames[key] ?? []
            return (key, bytes.map { String(format: "%02X", $0) }.joined(separator: " "))
        }
    }
}
