import Foundation
import SwiftUI
import Combine
import CoreLocation
import MediaPlayer
import UIKit

// MARK: - Settings enums

enum ThemeMode: String, CaseIterable, Identifiable {
    case dark, light, auto
    var id: String { rawValue }

    var title: String {
        switch self {
        case .dark: return "Dark"
        case .light: return "Light"
        case .auto: return "Auto"
        }
    }

    var symbol: String {
        switch self {
        case .dark: return "moon.stars.fill"
        case .light: return "sun.max.fill"
        case .auto: return "circle.lefthalf.filled"
        }
    }

    var next: ThemeMode {
        switch self {
        case .dark: return .light
        case .light: return .auto
        case .auto: return .dark
        }
    }

    func scheme(isNight: Bool) -> ColorScheme {
        switch self {
        case .dark: return .dark
        case .light: return .light
        case .auto: return isNight ? .dark : .light
        }
    }
}

enum TextSizeOption: String, CaseIterable, Identifiable {
    case small, medium, large
    var id: String { rawValue }

    var title: String {
        switch self {
        case .small: return "Small"
        case .medium: return "Medium"
        case .large: return "Large"
        }
    }

    var scale: CGFloat {
        switch self {
        case .small: return 0.85
        case .medium: return 1.0
        case .large: return 1.18
        }
    }
}

/// Font scale for the landscape cluster (Settings > Text size).
private struct DashScaleKey: EnvironmentKey {
    static let defaultValue: CGFloat = 1
}

extension EnvironmentValues {
    var dashScale: CGFloat {
        get { self[DashScaleKey.self] }
        set { self[DashScaleKey.self] = newValue }
    }
}

/// Colors that follow the Dark / Light theme.
enum DashColors {
    static func background(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(white: 0.04) : Color(white: 0.95)
    }

    static func carBody(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(white: 0.06) : Color.white
    }

    static func tire(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(white: 0.35) : Color(white: 0.55)
    }
}

// MARK: - Location (foreground only)

/// Wraps CLLocationManager. When-in-use authorization only; stopped when the app goes to the background.
/// Not actor-isolated on purpose: CLLocationManager is created on the main thread, so its
/// delegate callbacks arrive on the main thread too.
final class LocationService: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var location: CLLocation?
    @Published private(set) var authorization: CLAuthorizationStatus = .notDetermined

    private let manager = CLLocationManager()
    private var wantsUpdates = false

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        manager.distanceFilter = 5
        manager.activityType = .automotiveNavigation
        authorization = manager.authorizationStatus
    }

    var isAuthorized: Bool {
        authorization == .authorizedWhenInUse || authorization == .authorizedAlways
    }

    func start() {
        wantsUpdates = true
        let status = manager.authorizationStatus
        authorization = status
        if status == .notDetermined {
            manager.requestWhenInUseAuthorization()
        } else if status == .authorizedWhenInUse || status == .authorizedAlways {
            manager.startUpdatingLocation()
        }
    }

    func stop() {
        wantsUpdates = false
        manager.stopUpdatingLocation()
    }

    /// Best accuracy while navigating, ~10 m otherwise.
    func setNavigationAccuracy(_ on: Bool) {
        manager.desiredAccuracy = on ? kCLLocationAccuracyBestForNavigation : kCLLocationAccuracyNearestTenMeters
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        DispatchQueue.main.async {
            self.authorization = status
            if self.wantsUpdates && (status == .authorizedWhenInUse || status == .authorizedAlways) {
                self.manager.startUpdatingLocation()
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let last = locations.last else { return }
        DispatchQueue.main.async {
            self.location = last
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // Ignore: no fix yet, or the user denied access.
    }
}

// MARK: - Sunrise / sunset

/// Simple sunrise equation (NOAA/Wikipedia form, ±a few minutes). Good enough for theme switching.
enum Solar {
    /// Returns .some((sunrise, sunset)) for the solar day `n`, .some(nil) for polar night,
    /// and nil for midnight sun.
    private static func riseSet(julianDay n: Double, lat: Double, lon: Double) -> (sunrise: Date, sunset: Date)?? {
        let rad = Double.pi / 180
        let jStar = n - lon / 360
        let m = (357.5291 + 0.98560028 * jStar).truncatingRemainder(dividingBy: 360)
        let c = 1.9148 * sin(m * rad) + 0.02 * sin(2 * m * rad) + 0.0003 * sin(3 * m * rad)
        let lambda = (m + c + 180 + 102.9372).truncatingRemainder(dividingBy: 360)
        let jTransit = 2451545.0 + jStar + 0.0053 * sin(m * rad) - 0.0069 * sin(2 * lambda * rad)
        let sinDec = sin(lambda * rad) * sin(23.4397 * rad)
        let cosDec = cos(asin(sinDec))
        let cosOmega = (sin(-0.833 * rad) - sin(lat * rad) * sinDec) / (cos(lat * rad) * cosDec)
        if cosOmega > 1 { return .some(nil) }     // sun never rises
        if cosOmega < -1 { return nil }           // sun never sets
        let omega = acos(cosOmega) / rad
        let riseDate = date(fromJulian: jTransit - omega / 360)
        let setDate = date(fromJulian: jTransit + omega / 360)
        return .some((sunrise: riseDate, sunset: setDate))
    }

    private static func date(fromJulian j: Double) -> Date {
        Date(timeIntervalSince1970: (j - 2440587.5) * 86400)
    }

    /// True when the sun is down at `date` for the given position.
    static func isNight(at date: Date, lat: Double, lon: Double) -> Bool {
        let jd = date.timeIntervalSince1970 / 86400 + 2440587.5
        let n = (jd - 2451545.0 + 0.0008).rounded(.up)
        for offset in [-1.0, 0.0, 1.0] {
            let result = riseSet(julianDay: n + offset, lat: lat, lon: lon)
            switch result {
            case .none:
                return false                       // midnight sun
            case .some(.none):
                return true                        // polar night
            case .some(.some(let pair)):
                if date >= pair.sunrise && date <= pair.sunset { return false }
            }
        }
        return true
    }

    /// Fallback when location is unknown: night from 7 pm to 7 am.
    static func isNightByClock(_ date: Date) -> Bool {
        let hour = Calendar.current.component(.hour, from: date)
        return hour >= 19 || hour < 7
    }
}

/// Decides whether "Auto" theme should be dark right now. Rechecks every minute.
@MainActor
final class ThemeController: ObservableObject {
    @Published private(set) var isNight: Bool = Solar.isNightByClock(Date())

    private weak var location: LocationService?
    private var timer: Timer?

    init() {
        timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.recompute() }
        }
    }

    func attach(_ location: LocationService) {
        self.location = location
        recompute()
    }

    func recompute() {
        let now = Date()
        let night: Bool
        if let loc = location?.location {
            night = Solar.isNight(at: now, lat: loc.coordinate.latitude, lon: loc.coordinate.longitude)
        } else {
            night = Solar.isNightByClock(now)
        }
        if night != isNight { isNight = night }
    }
}

// MARK: - Weather (Open-Meteo, no key)

struct WeatherNow: Equatable {
    var temperatureF: Double
    var code: Int
    var isDay: Bool
    var fetched: Date

    /// SF Symbol for a WMO weather code.
    var symbol: String {
        switch code {
        case 0: return isDay ? "sun.max.fill" : "moon.stars.fill"
        case 1, 2: return isDay ? "cloud.sun.fill" : "cloud.moon.fill"
        case 3: return "cloud.fill"
        case 45, 48: return "cloud.fog.fill"
        case 51, 53, 55, 56, 57: return "cloud.drizzle.fill"
        case 61, 63, 66, 80, 81: return "cloud.rain.fill"
        case 65, 67, 82: return "cloud.heavyrain.fill"
        case 71, 73, 75, 77, 85, 86: return "cloud.snow.fill"
        case 95, 96, 99: return "cloud.bolt.rain.fill"
        default: return isDay ? "sun.max.fill" : "moon.fill"
        }
    }

    var summary: String {
        switch code {
        case 0: return "Clear"
        case 1: return "Mostly clear"
        case 2: return "Partly cloudy"
        case 3: return "Overcast"
        case 45, 48: return "Fog"
        case 51, 53, 55, 56, 57: return "Drizzle"
        case 61, 63, 65, 66, 67: return "Rain"
        case 71, 73, 75, 77: return "Snow"
        case 80, 81, 82: return "Showers"
        case 85, 86: return "Snow showers"
        case 95, 96, 99: return "Thunderstorm"
        default: return ""
        }
    }
}

private struct OpenMeteoResponse: Decodable {
    struct Current: Decodable {
        let temperature_2m: Double?
        let weather_code: Int?
        let is_day: Int?
    }
    let current: Current?
}

/// Fetches current conditions every 15 minutes over cellular. The Commander's Wi-Fi has
/// no internet, so this simply fails silently when there is no route out.
@MainActor
final class WeatherService: ObservableObject {
    @Published private(set) var current: WeatherNow?

    private weak var location: LocationService?
    private var timer: Timer?
    private var lastAttempt = Date.distantPast
    private var lastSuccess = Date.distantPast
    private var inFlight = false

    init() {
        timer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refreshIfDue() }
        }
    }

    func attach(_ location: LocationService) {
        self.location = location
        refreshIfDue()
    }

    func refreshIfDue() {
        let enabled = (UserDefaults.standard.object(forKey: "showWeather") as? Bool) ?? true
        guard enabled, !inFlight, let loc = location?.location else { return }
        let now = Date()
        // Every 15 min after a success; retry failures every 2 min.
        guard now.timeIntervalSince(lastSuccess) >= 15 * 60, now.timeIntervalSince(lastAttempt) >= 120 else { return }
        lastAttempt = now
        inFlight = true
        let lat = loc.coordinate.latitude
        let lon = loc.coordinate.longitude
        Task { [weak self] in
            let result = await WeatherService.fetch(lat: lat, lon: lon)
            guard let self else { return }
            self.inFlight = false
            if let result {
                self.current = result
                self.lastSuccess = Date()
            }
        }
    }

    nonisolated private static func fetch(lat: Double, lon: Double) async -> WeatherNow? {
        let urlString = String(format: "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,is_day&temperature_unit=fahrenheit", lat, lon)
        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url)
        request.timeoutInterval = 15
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, http.statusCode != 200 { return nil }
            let decoded = try JSONDecoder().decode(OpenMeteoResponse.self, from: data)
            guard let c = decoded.current, let t = c.temperature_2m, let code = c.weather_code else { return nil }
            return WeatherNow(temperatureF: t, code: code, isDay: (c.is_day ?? 1) == 1, fetched: Date())
        } catch {
            return nil
        }
    }
}

// MARK: - Music (Apple Music / Music app only)

/// Now playing from the system Music app via MPMusicPlayerController.systemMusicPlayer.
/// NOTE: Only Apple Music / the Music app can be read and controlled this way.
/// Spotify (and other third-party players) cannot be read without the Spotify iOS SDK
/// (App Remote), which this app deliberately does not include.
@MainActor
final class MusicModel: ObservableObject {
    @Published private(set) var title: String?
    @Published private(set) var artist: String?
    @Published private(set) var artwork: UIImage?
    @Published private(set) var isPlaying = false
    @Published private(set) var authorization: MPMediaLibraryAuthorizationStatus = MPMediaLibrary.authorizationStatus()

    private var player: MPMusicPlayerController?
    private var observers: [NSObjectProtocol] = []

    /// Call when the music panel first appears (asks for Media & Apple Music access once).
    func activate() {
        let status = MPMediaLibrary.authorizationStatus()
        authorization = status
        if status == .notDetermined {
            MPMediaLibrary.requestAuthorization { newStatus in
                Task { @MainActor [weak self] in
                    self?.authorization = newStatus
                    self?.attachPlayer()
                }
            }
        } else {
            attachPlayer()
        }
    }

    private func attachPlayer() {
        if player == nil {
            let p = MPMusicPlayerController.systemMusicPlayer
            player = p
            p.beginGeneratingPlaybackNotifications()
            let center = NotificationCenter.default
            let names: [Notification.Name] = [
                .MPMusicPlayerControllerNowPlayingItemDidChange,
                .MPMusicPlayerControllerPlaybackStateDidChange
            ]
            for name in names {
                let token = center.addObserver(forName: name, object: p, queue: .main) { [weak self] _ in
                    Task { @MainActor in self?.refresh() }
                }
                observers.append(token)
            }
        }
        refresh()
    }

    func refresh() {
        guard let p = player else { return }
        let item = p.nowPlayingItem
        title = item?.title
        artist = item?.artist
        artwork = item?.artwork?.image(at: CGSize(width: 240, height: 240))
        isPlaying = p.playbackState == .playing
    }

    func togglePlay() {
        guard let p = player else { activate(); return }
        if p.playbackState == .playing { p.pause() } else { p.play() }
        refreshSoon()
    }

    func next() {
        player?.skipToNextItem()
        refreshSoon()
    }

    func previous() {
        player?.skipToPreviousItem()
        refreshSoon()
    }

    private func refreshSoon() {
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 400_000_000)
            self?.refresh()
        }
    }
}
