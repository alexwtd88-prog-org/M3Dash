import Foundation
import SwiftUI
import CoreLocation

struct TripRecord: Codable, Identifiable {
    var id = UUID()
    var start: Date
    var end: Date
    var miles: Double
    var kWh: Double
    var peakKW: Double
    var peakRegenKW: Double
    var maxMph: Double
    var drivingSeconds: Double
    // v1.2 additions. Optional so trips saved by older versions still decode.
    var graph: [TripGraphPoint]? = nil
    var startPlace: String? = nil
    var endPlace: String? = nil
    var whPerMile: Double? { miles > 0.05 ? kWh * 1000 / miles : nil }
    var avgMph: Double? { drivingSeconds > 10 ? miles / (drivingSeconds / 3600) : nil }
}

/// Compact, Codable copy of an EnergyPoint stored with a finished trip.
struct TripGraphPoint: Codable, Equatable {
    var m: Double   // miles into the drive
    var w: Double   // Wh/mi
}

/// What the car icon shows: lights, doors, blind spot, turn signals.
struct CarIconStatus: Equatable {
    var leftTurn = false
    var rightTurn = false
    var blindLeft = 0      // 0 none, 1 or 2 warning level
    var blindRight = 0
    var lowBeam = false
    var highBeam = false
    var brake = false
    var doorsOpen: [Bool] = [false, false, false, false]   // FL, FR, RL, RR
    var trunkOpen = false
}

/// One point on the Current Drive energy graph.
struct EnergyPoint: Identifiable {
    let id = UUID()
    let miles: Double      // distance into the drive
    let whPerMile: Double  // smoothed consumption at that point
}

struct ChargeRecord: Codable, Identifiable {
    var id = UUID()
    var start: Date
    var end: Date
    var kWhAdded: Double
    var peakKW: Double
    var startSOC: Double?
    var endSOC: Double?
    var milesAdded: Double?
}

@MainActor
final class VehicleStore: ObservableObject {
    // Settings
    @Published var host: String = UserDefaults.standard.string(forKey: "host") ?? "192.168.4.1" {
        didSet { UserDefaults.standard.set(host, forKey: "host") }
    }
    @Published var port: Int = (UserDefaults.standard.object(forKey: "port") as? Int) ?? 1338 {
        didSet { UserDefaults.standard.set(port, forKey: "port") }
    }
    @Published var metric: Bool = UserDefaults.standard.bool(forKey: "metric") {
        didSet { UserDefaults.standard.set(metric, forKey: "metric") }
    }
    @Published var keepAwake: Bool = (UserDefaults.standard.object(forKey: "keepAwake") as? Bool) ?? true {
        didSet { UserDefaults.standard.set(keepAwake, forKey: "keepAwake") }
    }

    // Live
    @Published private(set) var snap = CANSnapshot()
    @Published private(set) var status: PandaClient.Status = .idle
    @Published private(set) var framesPerSecond = 0
    @Published private(set) var seenIDs: Set<UInt32> = []
    /// Which bus each CAN ID is read from (first one seen wins).
    private(set) var busLock: [UInt32: UInt8] = [:]
    /// Latest raw bytes per "bus:id" (and per mux index for 0x219 / 0x243), for Settings > Raw data.
    private(set) var rawFrames: [String: [UInt8]] = [:]
    @Published var demoMode = false

    // Trip (current drive) and Trip A (since reset)
    @Published private(set) var drive: TripRecord?
    @Published private(set) var driveGraph: [EnergyPoint] = []
    private var graphLastMiles = 0.0
    private var graphLastKWh = 0.0
    private var graphRecent: [Double] = []
    @Published private(set) var tripA: TripRecord
    @Published private(set) var trips: [TripRecord] = []
    // Charging
    @Published private(set) var charge: ChargeRecord?
    @Published private(set) var charges: [ChargeRecord] = []
    // 0-60
    @Published private(set) var lastZeroToSixty: Double?
    @Published private(set) var bestZeroToSixty: Double?
    // Turn signals, held on between flashes so the UI can blink them steadily.
    @Published private(set) var turnLeftActive = false
    @Published private(set) var turnRightActive = false
    // Bumped each time a hard launch is detected ("Toybox" effect).
    @Published private(set) var launchEffectCount = 0

    /// Supplies the phone's current location (set by the app at launch). Used for trip place names.
    var locationProvider: (() -> CLLocation?)?
    private var lastLeftOn: Date?
    private var lastRightOn: Date?
    private var speedHistory: [(t: Date, mph: Double)] = []
    private var lastLaunchEffect = Date.distantPast

    private let client = PandaClient()
    private var frameCounter = 0
    private var fpsTimer: Timer?
    private var tickTimer: Timer?
    private var demoTimer: Timer?
    private var demoT: Double = 0
    private var lastTick = Date()
    private var parkedSince: Date?
    private var driveStartOdo: Double?
    private var driveStartDischarge: Double?
    private var driveStartCharge: Double?
    private var tripAStartOdo: Double?
    private var tripAStartDischarge: Double?
    private var tripAStartCharge: Double?
    private var chargeStartTotal: Double?
    private var chargeStartRange: Double?
    private var chargeIntegratedKWh = 0.0
    private var launchStart: Date?
    private var notChargingSince: Date?

    init() {
        let d = UserDefaults.standard
        if let data = d.data(forKey: "trips"), let t = try? JSONDecoder().decode([TripRecord].self, from: data) { trips = t }
        if let data = d.data(forKey: "charges"), let c = try? JSONDecoder().decode([ChargeRecord].self, from: data) { charges = c }
        if let data = d.data(forKey: "tripA"), let a = try? JSONDecoder().decode(TripRecord.self, from: data) {
            tripA = a
        } else {
            tripA = TripRecord(start: Date(), end: Date(), miles: 0, kWh: 0, peakKW: 0, peakRegenKW: 0, maxMph: 0, drivingSeconds: 0)
        }
        tripAStartOdo = d.object(forKey: "tripAStartOdo") as? Double
        tripAStartDischarge = d.object(forKey: "tripAStartDischarge") as? Double
        tripAStartCharge = d.object(forKey: "tripAStartCharge") as? Double
        bestZeroToSixty = d.object(forKey: "best060") as? Double

        client.onStatus = { [weak self] s in
            Task { @MainActor in self?.status = s }
        }
        client.onFrames = { [weak self] frames in
            Task { @MainActor in self?.ingest(frames) }
        }
        fpsTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                self.framesPerSecond = self.frameCounter
                self.frameCounter = 0
            }
        }
        tickTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    // MARK: - Connection

    func connect() {
        guard !demoMode else { return }
        client.start(host: host, port: UInt16(clamping: port), ids: CANDecoder.subscribedIDs)
    }

    func disconnect() { client.stop() }

    func reconnect() {
        busLock = [:]
        client.stop()
        connect()
    }

    func setDemo(_ on: Bool) {
        demoMode = on
        if on {
            client.stop()
            status = .streaming
            demoT = 0
            demoTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.demoStep() }
            }
        } else {
            demoTimer?.invalidate()
            demoTimer = nil
            snap = CANSnapshot()
            connect()
        }
    }

    private func ingest(_ frames: [CANFrame]) {
        var s = snap
        for f in frames {
            // The Commander forwards two CAN buses, and the same ID can mean
            // different things on each. Stick with the first bus an ID shows up on.
            var rawKey = "\(f.bus):" + String(format: "%03X", f.id)
            if (f.id == 0x219 || f.id == 0x243), let b0 = f.data.first { rawKey += " m\(b0 & 0x3)" }
            rawFrames[rawKey] = f.data
            if let locked = busLock[f.id] {
                if locked != f.bus { continue }
            } else {
                busLock[f.id] = f.bus
            }
            CANDecoder.apply(f, to: &s)
            seenIDs.insert(f.id)
        }
        frameCounter += frames.count
        snap = s
    }

    // MARK: - Derived values

    var speedMph: Double? {
        if let ui = snap.uiSpeed, let isKph = snap.uiSpeedIsKph, ui < 500 {
            return isKph ? ui * 0.621371 : ui
        }
        return snap.speedKph.map { max(0, $0) * 0.621371 }
    }

    /// Battery power in kW: + = drawing from the pack, − = regen/charging.
    var batteryPowerKW: Double? {
        guard let v = snap.packVoltage, let i = snap.packCurrent else { return nil }
        return v * i / 1000
    }

    /// Prefer UI_SOC (0x33A), the whole-number % the Tesla screen shows.
    var socPercent: Double? {
        // BMS SOC UI (0x292) matches the Tesla screen; the car shows it rounded down.
        // (0x33A UI_SOC reads garbage on this car, e.g. 111.)
        guard let soc = snap.socUI else { return nil }
        return min(100, max(0, soc.rounded(.up)))
    }
    var rangeMiles: Double? { snap.ratedRangeMi }
    /// FSD / Autopilot engaged (DAS_autopilotState 3, 4, 5; 6 = FSD on this car, seen Nov 9 2026).
    var autopilotActive: Bool { [3, 4, 5, 6].contains(snap.autopilotState ?? 0) }

    var isCharging: Bool {
        if snap.uiChargeStatus == 3 { return true }
        if let p = batteryPowerKW, p < -0.8, snap.gear == nil || snap.gear == 1, (speedMph ?? 0) < 1 { return true }
        return false
    }

    var isDCFast: Bool { isCharging && (-(batteryPowerKW ?? 0)) > 20 }

    var chargePowerKW: Double? {
        guard isCharging else { return nil }
        if let p = batteryPowerKW, p < 0 { return -p }
        return snap.acLinePowerKW
    }

    /// Rated miles added per hour of charging at the current rate.
    var milesPerHourAdded: Double? {
        guard let kw = chargePowerKW, kw > 0 else { return nil }
        let wh = (snap.ratedWhPerMi ?? 0) > 150 ? snap.ratedWhPerMi! : 245
        return kw * 1000 / wh
    }

    var minutesToFull: Double? {
        if let m = snap.chargeMinutesRemaining, m > 0 { return m }
        if let e = snap.energyToChargeCompleteKWh, let kw = chargePowerKW, kw > 0.5 { return e / kw * 60 }
        return nil
    }

    var gearLetter: String {
        switch snap.gear {
        case 1: return "P"
        case 2: return "R"
        case 3: return "N"
        case 4: return "D"
        default: return "–"
        }
    }

    // MARK: - Trip & charge bookkeeping

    private func tick() {
        let now = Date()
        let dt = now.timeIntervalSince(lastTick)
        lastTick = now
        let mph = speedMph ?? 0
        let power = batteryPowerKW ?? 0
        let driving = snap.gear == 2 || snap.gear == 4 || mph > 1

        // Drive session
        if driving {
            parkedSince = nil
            if drive == nil { beginDrive(now) }
        } else if drive != nil {
            if parkedSince == nil { parkedSince = now }
            if let p = parkedSince, now.timeIntervalSince(p) > 300 { endDrive(now) }
        }
        if var dr = drive {
            update(&dr, now: now, dt: dt, mph: mph, power: power, driving: driving,
                   startOdo: driveStartOdo, startDis: driveStartDischarge, startChg: driveStartCharge)
            drive = dr
            sampleGraph(dr)
        }
        if snap.odometerKm != nil, tripAStartOdo == nil { resetTripA() }
        var a = tripA
        update(&a, now: now, dt: dt, mph: mph, power: power, driving: driving,
               startOdo: tripAStartOdo, startDis: tripAStartDischarge, startChg: tripAStartCharge)
        tripA = a

        // Turn signals: lamp status flashes, so hold "active" for 1 s after the last ON.
        if snap.turnSignalLeft == 1 { lastLeftOn = now }
        if snap.turnSignalRight == 1 { lastRightOn = now }
        let leftActive = lastLeftOn.map { now.timeIntervalSince($0) < 1.0 } ?? false
        let rightActive = lastRightOn.map { now.timeIntervalSince($0) < 1.0 } ?? false
        if leftActive != turnLeftActive { turnLeftActive = leftActive }
        if rightActive != turnRightActive { turnRightActive = rightActive }

        detectLaunch(now: now, mph: mph)

        // 0-60 timer
        if mph < 0.5 && snap.gear == 4 { launchStart = nil; launchArmed = true }
        if launchArmed && mph >= 0.5 && launchStart == nil { launchStart = now }
        if let ls = launchStart, mph >= 60 {
            let t = now.timeIntervalSince(ls)
            if t > 1.5 && t < 20 {
                lastZeroToSixty = t
                if bestZeroToSixty == nil || t < bestZeroToSixty! {
                    bestZeroToSixty = t
                    UserDefaults.standard.set(t, forKey: "best060")
                }
            }
            launchStart = nil
            launchArmed = false
        }

        // Charge session
        if isCharging {
            notChargingSince = nil
            if charge == nil { beginCharge(now) }
            if var c = charge {
                let kw = chargePowerKW ?? 0
                chargeIntegratedKWh += kw * dt / 3600
                if let start = chargeStartTotal, let tot = snap.totalChargeKWh, tot >= start {
                    c.kWhAdded = tot - start
                } else {
                    c.kWhAdded = chargeIntegratedKWh
                }
                c.peakKW = max(c.peakKW, kw)
                c.end = now
                c.endSOC = socPercent
                if let r0 = chargeStartRange, let r = rangeMiles { c.milesAdded = max(0, r - r0) }
                charge = c
            }
        } else if charge != nil {
            if notChargingSince == nil { notChargingSince = now }
            if let n = notChargingSince, now.timeIntervalSince(n) > 60 { endCharge() }
        }
    }

    private var launchArmed = false

    /// Hard-acceleration detector for the launch effect. Needs accel pedal > 80 %
    /// and a speed gain over the last second that beats the chosen sensitivity.
    private func detectLaunch(now: Date, mph: Double) {
        speedHistory.append((t: now, mph: mph))
        speedHistory.removeAll { now.timeIntervalSince($0.t) > 2.5 }
        let d = UserDefaults.standard
        let enabled = (d.object(forKey: "launchEffect") as? Bool) ?? true
        guard enabled, let pedal = snap.accelPedal, pedal > 80 else { return }
        guard let old = speedHistory.last(where: { now.timeIntervalSince($0.t) >= 1.0 }) else { return }
        let dt = now.timeIntervalSince(old.t)
        guard dt > 0.5 else { return }
        let rate = (mph - old.mph) / dt   // mph per second
        let sensitivity = (d.object(forKey: "launchSensitivity") as? Int) ?? 1
        let threshold: Double
        switch sensitivity {
        case 0: threshold = 9     // Low: only big launches
        case 2: threshold = 4     // High: triggers easily
        default: threshold = 6    // Medium
        }
        if rate >= threshold, now.timeIntervalSince(lastLaunchEffect) > 8 {
            lastLaunchEffect = now
            launchEffectCount += 1
        }
    }

    // MARK: - Car icon status

    var carStatus: CarIconStatus {
        var c = CarIconStatus()
        c.leftTurn = turnLeftActive
        c.rightTurn = turnRightActive
        c.blindLeft = snap.blindSpotLeftLevel
        c.blindRight = snap.blindSpotRightLevel
        c.lowBeam = snap.lowBeamOn
        c.highBeam = snap.highBeamOn
        c.brake = snap.brakeOn
        c.doorsOpen = snap.doorsOpen
        c.trunkOpen = snap.trunkOpen
        return c
    }

    // MARK: - Navigation helpers

    /// Estimated battery % on arrival: SOC − miles × Wh/mi ÷ usable pack kWh.
    func arrivalSOC(remainingMiles: Double) -> Double? {
        guard let soc = socPercent else { return nil }
        var whPerMi = 250.0
        if let d = drive, d.miles > 0.5, let w = d.whPerMile, w > 50 {
            whPerMi = w
        } else if let r = snap.ratedWhPerMi, r > 100 {
            whPerMi = r
        }
        let pack = (snap.nominalFullPackKWh ?? 0) > 40 ? snap.nominalFullPackKWh! : 75
        return soc - remainingMiles * whPerMi / (pack * 1000) * 100
    }

    private func update(_ t: inout TripRecord, now: Date, dt: Double, mph: Double, power: Double, driving: Bool,
                        startOdo: Double?, startDis: Double?, startChg: Double?) {
        t.end = now
        if driving { t.drivingSeconds += dt }
        t.maxMph = max(t.maxMph, mph)
        t.peakKW = max(t.peakKW, power)
        if driving { t.peakRegenKW = max(t.peakRegenKW, -power) }
        if let o0 = startOdo, let o = snap.odometerKm {
            t.miles = max(0, (o - o0) * 0.621371)
        } else if driving {
            t.miles += mph * dt / 3600
        }
        if let d0 = startDis, let c0 = startChg, let d = snap.totalDischargeKWh, let c = snap.totalChargeKWh {
            // Net energy: discharge minus regen. Excludes plug-in charging, which happens while parked.
            t.kWh = max(0, (d - d0) - (c - c0))
        } else if driving {
            t.kWh += power * dt / 3600
        }
    }

    /// Adds a graph point every 0.2 mi, smoothed over the last ~0.6 mi.
    private func sampleGraph(_ t: TripRecord) {
        let dMi = t.miles - graphLastMiles
        guard dMi >= 0.2 else { return }
        let dKWh = t.kWh - graphLastKWh
        graphLastMiles = t.miles
        graphLastKWh = t.kWh
        let raw = min(max(dKWh * 1000 / dMi, -400), 900)
        graphRecent.append(raw)
        if graphRecent.count > 3 { graphRecent.removeFirst() }
        let smooth = graphRecent.reduce(0, +) / Double(graphRecent.count)
        driveGraph.append(EnergyPoint(miles: t.miles, whPerMile: smooth))
        if driveGraph.count > 800 {
            // Halve resolution on very long drives.
            driveGraph = stride(from: 0, to: driveGraph.count, by: 2).map { driveGraph[$0] }
        }
    }

    /// Range left if you keep driving the way this drive has gone.
    var projectedRangeMiles: Double? {
        guard let r = rangeMiles, let rated = snap.ratedWhPerMi, rated > 0,
              let avg = drive?.whPerMile, avg > 50 else { return nil }
        return r * rated / avg
    }

    private func beginDrive(_ now: Date) {
        driveGraph = []
        graphLastMiles = 0
        graphLastKWh = 0
        graphRecent = []
        driveStartOdo = snap.odometerKm
        driveStartDischarge = snap.totalDischargeKWh
        driveStartCharge = snap.totalChargeKWh
        let record = TripRecord(start: now, end: now, miles: 0, kWh: 0, peakKW: 0, peakRegenKW: 0, maxMph: 0, drivingSeconds: 0)
        drive = record
        let driveID = record.id
        if let loc = locationProvider?() {
            Task { [weak self] in
                let name = await PlaceNamer.name(for: loc)
                guard let self, let name else { return }
                if self.drive?.id == driveID {
                    self.drive?.startPlace = name
                } else if let i = self.trips.firstIndex(where: { $0.id == driveID }) {
                    self.trips[i].startPlace = name
                    self.save()
                }
            }
        }
    }

    private func endDrive(_ now: Date) {
        if var d = drive, d.miles > 0.1 {
            d.graph = VehicleStore.downsample(driveGraph, maxPoints: 120)
            trips.insert(d, at: 0)
            if trips.count > VehicleStore.maxTrips { trips.removeLast(trips.count - VehicleStore.maxTrips) }
            save()
            let tripID = d.id
            if let loc = locationProvider?() {
                Task { [weak self] in
                    let name = await PlaceNamer.name(for: loc)
                    guard let self, let name else { return }
                    if let i = self.trips.firstIndex(where: { $0.id == tripID }) {
                        self.trips[i].endPlace = name
                        self.save()
                    }
                }
            }
        }
        drive = nil
        parkedSince = nil
    }

    static let maxTrips = 200

    /// Evenly picks at most `maxPoints` points, always keeping the last one.
    static func downsample(_ points: [EnergyPoint], maxPoints: Int) -> [TripGraphPoint] {
        let all = points.map { TripGraphPoint(m: $0.miles, w: $0.whPerMile) }
        guard all.count > maxPoints, maxPoints > 1 else { return all }
        var out: [TripGraphPoint] = []
        out.reserveCapacity(maxPoints)
        let step = Double(all.count - 1) / Double(maxPoints - 1)
        for i in 0..<maxPoints {
            let idx = min(all.count - 1, Int((Double(i) * step).rounded()))
            out.append(all[idx])
        }
        return out
    }

    // MARK: - Trip history export / import

    func exportTripsData() -> Data {
        (try? JSONEncoder.tripEncoder.encode(trips)) ?? Data()
    }

    /// Merges trips from a JSON export. Returns how many new trips were added.
    @discardableResult
    func importTrips(from data: Data) throws -> Int {
        let incoming = try JSONDecoder.tripDecoder.decode([TripRecord].self, from: data)
        let known = Set(trips.map { $0.id })
        let fresh = incoming.filter { !known.contains($0.id) }
        var merged = trips + fresh
        merged.sort { $0.start > $1.start }
        if merged.count > VehicleStore.maxTrips { merged.removeLast(merged.count - VehicleStore.maxTrips) }
        trips = merged
        save()
        return fresh.count
    }

    func endDriveNow() { endDrive(Date()) }

    func resetTripA() {
        tripAStartOdo = snap.odometerKm
        tripAStartDischarge = snap.totalDischargeKWh
        tripAStartCharge = snap.totalChargeKWh
        tripA = TripRecord(start: Date(), end: Date(), miles: 0, kWh: 0, peakKW: 0, peakRegenKW: 0, maxMph: 0, drivingSeconds: 0)
        let d = UserDefaults.standard
        d.set(tripAStartOdo, forKey: "tripAStartOdo")
        d.set(tripAStartDischarge, forKey: "tripAStartDischarge")
        d.set(tripAStartCharge, forKey: "tripAStartCharge")
        save()
    }

    private func beginCharge(_ now: Date) {
        chargeStartTotal = snap.totalChargeKWh
        chargeStartRange = rangeMiles
        chargeIntegratedKWh = 0
        charge = ChargeRecord(start: now, end: now, kWhAdded: 0, peakKW: 0, startSOC: socPercent, endSOC: socPercent)
    }

    private func endCharge() {
        if let c = charge, c.kWhAdded > 0.2 {
            charges.insert(c, at: 0)
            if charges.count > 50 { charges.removeLast(charges.count - 50) }
            save()
        }
        charge = nil
        notChargingSince = nil
    }

    func clearHistory() {
        trips = []
        charges = []
        bestZeroToSixty = nil
        UserDefaults.standard.removeObject(forKey: "best060")
        save()
    }

    private func save() {
        let d = UserDefaults.standard
        d.set(try? JSONEncoder().encode(trips), forKey: "trips")
        d.set(try? JSONEncoder().encode(charges), forKey: "charges")
        d.set(try? JSONEncoder().encode(tripA), forKey: "tripA")
    }

    // MARK: - Demo data (for trying the app away from the car)

    private func demoStep() {
        demoT += 0.05
        var s = snap
        let phase = demoT.truncatingRemainder(dividingBy: 90)
        let charging = phase > 60
        s.packVoltage = 355 + sin(demoT / 7) * 5
        if charging {
            s.gear = 1
            s.speedKph = 0; s.uiSpeed = 0; s.uiSpeedIsKph = false
            s.packCurrent = -(120 + sin(demoT) * 10)
            s.uiChargeStatus = 3
            s.chargeMinutesRemaining = 42
            s.cablePresent = true
        } else {
            let mph = max(0, 45 + 30 * sin(demoT / 4))
            s.gear = 4
            s.uiSpeed = mph.rounded(); s.uiSpeedIsKph = false
            s.speedKph = mph / 0.621371
            s.packCurrent = 40 + 180 * cos(demoT / 4)
            s.uiChargeStatus = 0
            s.chargeMinutesRemaining = nil
            s.cablePresent = false
            s.odometerKm = (s.odometerKm ?? 48_210) + mph / 0.621371 * 0.05 / 3600
        }
        s.rearPowerKW = (s.packVoltage! * s.packCurrent! / 1000)
        s.socUI = 72 + sin(demoT / 30) * 3
        s.ratedRangeMi = (s.socUI! * 3.1).rounded()
        s.ratedWhPerMi = 245
        s.packTempMinC = 27; s.packTempMaxC = 29
        s.tirePressureBar = [2.90, 2.92, 2.88, 2.90]
        s.tireTempC = [24, 24, 23, 23]
        s.outsideTempC = 21
        s.cabinTempC = 22
        s.speedLimit = charging ? nil : 65

        // Car icon demo: turn signals, blind spot, lights, brake, doors.
        let blink = Int(demoT / 0.35) % 2 == 0
        let leftWindow = phase > 8 && phase < 15
        let rightWindow = phase > 33 && phase < 40
        s.turnSignalLeft = (leftWindow && blink) ? 1 : 0
        s.turnSignalRight = (rightWindow && blink) ? 1 : 0
        s.blindSpotLeft = (phase > 10 && phase < 14) ? (phase > 12 ? 2 : 1) : 0
        s.blindSpotRight = (phase > 35 && phase < 39) ? (phase > 37 ? 2 : 1) : 0
        s.lowBeamLeft = 1; s.lowBeamRight = 1
        let high = phase > 20 && phase < 28
        s.highBeamLeft = high ? 1 : 0; s.highBeamRight = high ? 1 : 0
        let accel = charging ? 0.0 : cos(demoT / 4)
        s.brakeLight = (!charging && accel < -0.35) ? 1 : 0
        s.brakePedal = s.brakeLight
        s.accelPedal = charging ? 0 : (accel > 0.6 ? 88 : max(0, accel * 60 + 15))
        s.latchFL = (phase > 62 && phase < 72) ? 1 : 2
        s.latchFR = 2; s.latchRL = 2; s.latchRR = 2
        s.latchTrunk = (phase > 75 && phase < 82) ? 1 : 2
        snap = s
        seenIDs = Set(CANDecoder.subscribedIDs)
        frameCounter += 20
    }
}

extension JSONEncoder {
    static var tripEncoder: JSONEncoder {
        let e = JSONEncoder()
        e.outputFormatting = [.prettyPrinted, .sortedKeys]
        return e
    }
}

extension JSONDecoder {
    static var tripDecoder: JSONDecoder { JSONDecoder() }
}

/// Reverse geocodes a location into a short place name ("Long Beach" / "Main St").
enum PlaceNamer {
    static func name(for location: CLLocation) async -> String? {
        await withCheckedContinuation { (cont: CheckedContinuation<String?, Never>) in
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { placemarks, _ in
                _ = geocoder   // keep the geocoder alive until it answers
                let p = placemarks?.first
                let street = p?.thoroughfare
                let city = p?.locality
                var result: String?
                if let street, let city {
                    result = "\(street), \(city)"
                } else {
                    result = p?.name ?? city ?? street
                }
                cont.resume(returning: result)
            }
        }
    }
}
