import Foundation

/// Little-endian (Intel, "@1") signal extraction, matching DBC semantics.
enum Bits {
    static func raw(_ d: [UInt8], start: Int, length: Int) -> UInt64 {
        var word: UInt64 = 0
        for (i, b) in d.prefix(8).enumerated() { word |= UInt64(b) << (8 * UInt64(i)) }
        let mask: UInt64 = length >= 64 ? .max : (1 << UInt64(length)) - 1
        return (word >> UInt64(start)) & mask
    }

    static func unsigned(_ d: [UInt8], _ start: Int, _ length: Int, scale: Double = 1, offset: Double = 0) -> Double {
        Double(raw(d, start: start, length: length)) * scale + offset
    }

    static func signed(_ d: [UInt8], _ start: Int, _ length: Int, scale: Double = 1, offset: Double = 0) -> Double {
        let r = raw(d, start: start, length: length)
        let signBit: UInt64 = 1 << UInt64(length - 1)
        let v: Int64 = (r & signBit) != 0 ? Int64(bitPattern: r | ~((signBit << 1) &- 1)) : Int64(r)
        return Double(v) * scale + offset
    }
}

/// Raw values decoded from the Model 3 CAN bus. Signal definitions come from
/// joshwardell/model3dbc (the database Scan My Tesla is built on).
struct CANSnapshot {
    // 0x132 HV battery
    var packVoltage: Double?          // V
    var packCurrent: Double?          // A, + = discharge
    var chargeMinutesRemaining: Double?
    // 0x257 speed
    var speedKph: Double?
    var uiSpeed: Double?
    var uiSpeedIsKph: Bool?
    // 0x292 BMS SOC
    var socUI: Double?                // %
    var socAvg: Double?
    // 0x33A UI range/SOC
    var ratedRangeMi: Double?
    var uiSOC: Double?
    var ratedWhPerMi: Double?
    // 0x352 energy
    var nominalFullPackKWh: Double?
    var nominalRemainingKWh: Double?
    var energyToChargeCompleteKWh: Double?
    // 0x3D2 lifetime counters
    var totalDischargeKWh: Double?
    var totalChargeKWh: Double?
    // 0x264 AC charge line
    var acLinePowerKW: Double?
    var acLineVoltage: Double?
    var acLineCurrent: Double?
    // 0x212 BMS status
    var uiChargeStatus: Int?          // 0 disc,1 no power,2 about to charge,3 charging,4 complete,5 stopped
    // 0x312 thermal
    var packTempMinC: Double?
    var packTempMaxC: Double?
    // 0x3B6 odometer
    var odometerKm: Double?
    // 0x266 / 0x2E5 inverter power
    var rearPowerKW: Double?
    var frontPowerKW: Double?
    // 0x118 drive status
    var gear: Int?                    // 1 P, 2 R, 3 N, 4 D
    var accelPedal: Double?
    // 0x25D charge port
    var cablePresent: Bool?
    // 0x219 TPMS (FL, FR, RL, RR)
    var tirePressureBar: [Double?] = [nil, nil, nil, nil]
    var tireTempC: [Double?] = [nil, nil, nil, nil]
    // 0x20C ambient, 0x243 cabin
    var outsideTempC: Double?
    var cabinTempC: Double?
    // 0x399 DAS speed limit (in the car's display units)
    var speedLimit: Double?
}

enum CANDecoder {
    static let subscribedIDs: [UInt32] = [
        0x132, 0x257, 0x292, 0x33A, 0x352, 0x3D2, 0x264, 0x212,
        0x312, 0x3B6, 0x266, 0x2E5, 0x118, 0x25D,
        0x219, 0x20C, 0x243, 0x399
    ]

    static func apply(_ f: CANFrame, to s: inout CANSnapshot) {
        let d = f.data
        switch f.id {
        case 0x132 where d.count >= 8:
            s.packVoltage = Bits.unsigned(d, 0, 16, scale: 0.01)
            s.packCurrent = Bits.signed(d, 16, 16, scale: -0.1)
            let mins = Bits.raw(d, start: 48, length: 12)
            s.chargeMinutesRemaining = mins >= 4095 ? nil : Double(mins)
        case 0x257 where d.count >= 6:
            s.speedKph = Bits.unsigned(d, 12, 12, scale: 0.08, offset: -40)
            s.uiSpeed = Bits.unsigned(d, 24, 9)
            s.uiSpeedIsKph = Bits.raw(d, start: 33, length: 1) == 1
        case 0x292 where d.count >= 5:
            s.socUI = Bits.unsigned(d, 10, 10, scale: 0.1)
            s.socAvg = Bits.unsigned(d, 30, 10, scale: 0.1)
        case 0x33A where d.count >= 7:
            s.ratedRangeMi = Bits.unsigned(d, 0, 10)
            s.ratedWhPerMi = Bits.unsigned(d, 32, 10)
            s.uiSOC = Bits.unsigned(d, 48, 7)
        case 0x352 where d.count >= 8:
            // Older firmware layout. Only trusted when the numbers are plausible,
            // since newer firmware multiplexes this frame.
            let full = Bits.unsigned(d, 0, 11, scale: 0.1)
            let remaining = Bits.unsigned(d, 11, 11, scale: 0.1)
            let toFull = Bits.unsigned(d, 44, 11, scale: 0.1)
            if full > 40, full < 110, remaining <= full + 1, toFull <= full + 1 {
                s.nominalFullPackKWh = full
                s.nominalRemainingKWh = remaining
                s.energyToChargeCompleteKWh = toFull
            }
        case 0x3D2 where d.count >= 8:
            let dis = Bits.unsigned(d, 0, 32, scale: 0.001)
            let chg = Bits.unsigned(d, 32, 32, scale: 0.001)
            if dis > 0 { s.totalDischargeKWh = dis }
            if chg > 0 { s.totalChargeKWh = chg }
        case 0x264 where d.count >= 4:
            s.acLineVoltage = Bits.unsigned(d, 0, 14, scale: 0.0333)
            s.acLineCurrent = Bits.unsigned(d, 14, 9, scale: 0.1)
            s.acLinePowerKW = Bits.unsigned(d, 24, 8, scale: 0.1)
        case 0x212 where d.count >= 2:
            s.uiChargeStatus = Int(Bits.raw(d, start: 11, length: 3))
        case 0x312 where d.count >= 8:
            s.packTempMinC = Bits.unsigned(d, 44, 9, scale: 0.25, offset: -25)
            s.packTempMaxC = Bits.unsigned(d, 53, 9, scale: 0.25, offset: -25)
        case 0x3B6 where d.count >= 4:
            let km = Bits.unsigned(d, 0, 32, scale: 0.001)
            if km > 0 { s.odometerKm = km }
        case 0x266 where d.count >= 2:
            s.rearPowerKW = Bits.signed(d, 0, 11, scale: 0.5)
        case 0x2E5 where d.count >= 2:
            s.frontPowerKW = Bits.signed(d, 0, 11, scale: 0.5)
        case 0x118 where d.count >= 5:
            s.gear = Int(Bits.raw(d, start: 21, length: 3))
            s.accelPedal = Bits.unsigned(d, 32, 8, scale: 0.4)
        case 0x25D where d.count >= 1:
            s.cablePresent = Bits.raw(d, start: 3, length: 1) == 1
        case 0x219 where d.count >= 5:
            let idx = Int(Bits.raw(d, start: 0, length: 2))
            let loc = Int(Bits.raw(d, start: 32, length: 3))
            let slot = loc < 4 ? loc : idx
            let p = Bits.raw(d, start: 8, length: 8)
            let t = Bits.raw(d, start: 16, length: 8)
            if p != 255 { s.tirePressureBar[slot] = Double(p) * 0.025 }
            if t != 255 { s.tireTempC[slot] = Double(t) - 40 }
        case 0x20C where d.count >= 7:
            let a = Bits.raw(d, start: 44, length: 8)
            if a != 255 { s.outsideTempC = Double(a) * 0.5 - 40 }
        case 0x243 where d.count >= 6:
            if Bits.raw(d, start: 0, length: 2) == 0 {
                let c = Bits.raw(d, start: 30, length: 11)
                if c != 2047 { s.cabinTempC = Double(c) * 0.1 - 40 }
            }
        case 0x399 where d.count >= 2:
            let l = Bits.raw(d, start: 8, length: 5)
            s.speedLimit = (l == 0 || l == 31) ? nil : Double(l) * 5
        default:
            break
        }
    }
}
