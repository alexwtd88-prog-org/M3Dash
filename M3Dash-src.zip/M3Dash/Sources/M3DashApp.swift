import SwiftUI

@main
struct M3DashApp: App {
    @StateObject private var store = VehicleStore()
    @StateObject private var location = LocationService()
    @StateObject private var nav = NavigationModel()
    @StateObject private var weather = WeatherService()
    @StateObject private var theme = ThemeController()
    @StateObject private var music = MusicModel()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(location)
                .environmentObject(nav)
                .environmentObject(weather)
                .environmentObject(theme)
                .environmentObject(music)
                .onAppear {
                    wireServices()
                    store.connect()
                    location.start()
                    UIApplication.shared.isIdleTimerDisabled = store.keepAwake
                }
                .onChange(of: phase) { _, newPhase in
                    switch newPhase {
                    case .active:
                        store.connect()
                        location.start()
                        theme.recompute()
                        weather.refreshIfDue()
                        UIApplication.shared.isIdleTimerDisabled = store.keepAwake
                    case .background:
                        store.disconnect()
                        location.stop()   // foreground-only location
                    default:
                        break
                    }
                }
        }
    }

    private func wireServices() {
        let loc = location
        store.locationProvider = { [weak loc] in loc?.location }
        nav.attach(loc)
        weather.attach(loc)
        theme.attach(loc)
    }
}

struct RootView: View {
    @Environment(\.verticalSizeClass) private var vSize
    @EnvironmentObject private var theme: ThemeController
    @EnvironmentObject private var location: LocationService
    @AppStorage("theme") private var themeRaw = ThemeMode.dark.rawValue

    var body: some View {
        ZStack {
            content
            LaunchEffectOverlay()
        }
        .preferredColorScheme(scheme)
        .onReceive(location.$location) { _ in
            // Location arriving (or moving far) can flip Auto between day and night.
            theme.recompute()
        }
    }

    private var scheme: ColorScheme {
        (ThemeMode(rawValue: themeRaw) ?? .dark).scheme(isNight: theme.isNight)
    }

    @ViewBuilder
    private var content: some View {
        if vSize == .compact {
            LandscapeDash()
        } else {
            tabs
        }
    }

    private var tabs: some View {
        TabView {
            DriveView()
                .tabItem { Label("Drive", systemImage: "speedometer") }
            MapTab()
                .tabItem { Label("Map", systemImage: "map") }
            ChargeView()
                .tabItem { Label("Charge", systemImage: "bolt.car") }
            TripsView()
                .tabItem { Label("Stats", systemImage: "chart.line.uptrend.xyaxis") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.red)
    }
}
