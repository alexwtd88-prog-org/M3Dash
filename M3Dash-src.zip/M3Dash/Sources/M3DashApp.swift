import SwiftUI

@main
struct M3DashApp: App {
    @StateObject private var store = VehicleStore()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
                .onAppear {
                    store.connect()
                    UIApplication.shared.isIdleTimerDisabled = store.keepAwake
                }
                .onChange(of: phase) { _, newPhase in
                    switch newPhase {
                    case .active:
                        store.connect()
                        UIApplication.shared.isIdleTimerDisabled = store.keepAwake
                    case .background:
                        store.disconnect()
                    default:
                        break
                    }
                }
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            DriveView()
                .tabItem { Label("Drive", systemImage: "speedometer") }
            ChargeView()
                .tabItem { Label("Charge", systemImage: "bolt.car") }
            TripsView()
                .tabItem { Label("Stats", systemImage: "chart.line.uptrend.xyaxis") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .tint(.red)
    }
}
