import Foundation
import Network
import Darwin

/// One CAN frame as forwarded by the S3XY Commander over Wi-Fi.
struct CANFrame {
    let bus: UInt8
    let id: UInt32
    let data: [UInt8]
}

/// Talks to the Enhance S3XY Commander's Wi-Fi access point using the
/// comma.ai "Panda" UDP protocol (the same interface Scan My Tesla uses).
///
/// Protocol (per tumik/S3XY-candump):
///  - send "ehllo" to 192.168.4.1:1338 at least once a second to keep the session alive
///  - the Commander answers with an ACK frame (bus 15, id 6); reply with a subscription packet:
///    0x0F followed by up to 42 triples [bus(0xFF = any), idHi, idLo]
///  - data arrives as UDP datagrams holding N x 16-byte frames:
///    uint32 LE word0 (id << 21 for standard ids), uint32 LE word1 (len & 0x0F, bus = >> 4), 8 data bytes
final class PandaClient {
    enum Status: Equatable {
        case idle
        case connecting
        case streaming
        case noResponse
        case failed(String)
    }

    var onFrames: (([CANFrame]) -> Void)?
    var onStatus: ((Status) -> Void)?

    private let queue = DispatchQueue(label: "m3dash.panda")
    private var sock: Int32 = -1
    private var readSource: DispatchSourceRead?
    private var heartbeat: DispatchSourceTimer?
    private var lastReceive: Date?
    private var reportedStreaming = false
    private var lastConnect = Date()
    private var subscribedIDs: [UInt32] = []
    private var host: String = "192.168.4.1"
    private var port: UInt16 = 1338
    private var running = false
    private var dest = sockaddr_in()

    /// Simple counters shown in Settings > Diagnostics.
    private(set) var packetsSent = 0
    private(set) var packetsReceived = 0
    private(set) var lastError: String = ""

    func start(host: String, port: UInt16, ids: [UInt32]) {
        queue.async {
            self.host = host
            self.port = port
            self.subscribedIDs = ids
            self.running = true
            self.connect()
            self.startHeartbeat()
        }
    }

    func stop() {
        queue.async {
            self.running = false
            self.heartbeat?.cancel()
            self.heartbeat = nil
            self.closeSocket()
            self.report(.idle)
        }
    }

    // MARK: - Connection (plain BSD UDP socket, bound to Wi-Fi)

    private func closeSocket() {
        if let src = readSource {
            readSource = nil
            src.cancel()   // the cancel handler closes the fd
        } else if sock >= 0 {
            close(sock)
        }
        sock = -1
    }

    private func connect() {
        closeSocket()
        lastReceive = nil
        reportedStreaming = false
        lastConnect = Date()
        report(.connecting)

        let fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard fd >= 0 else {
            fail("socket() failed: \(String(cString: strerror(errno)))")
            return
        }

        // Keep traffic on Wi-Fi (en0) even though that network has no internet.
        var ifIndex = UInt32(if_nametoindex("en0"))
        if ifIndex != 0 {
            _ = setsockopt(fd, IPPROTO_IP, IP_BOUND_IF, &ifIndex, socklen_t(MemoryLayout<UInt32>.size))
        }
        var on: Int32 = 1
        _ = setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))
        let flags = fcntl(fd, F_GETFL, 0)
        _ = fcntl(fd, F_SETFL, flags | O_NONBLOCK)

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = port.bigEndian
        guard inet_pton(AF_INET, host, &addr.sin_addr) == 1 else {
            close(fd)
            fail("Bad host address \(host)")
            return
        }
        dest = addr
        sock = fd

        let src = DispatchSource.makeReadSource(fileDescriptor: fd, queue: queue)
        src.setEventHandler { [weak self] in self?.readAvailable() }
        src.setCancelHandler { close(fd) }
        readSource = src
        src.resume()

        sendHello()
        sendSubscription()
    }

    private func fail(_ msg: String) {
        lastError = msg
        report(.failed(msg))
    }

    private func readAvailable() {
        guard sock >= 0 else { return }
        var buf = [UInt8](repeating: 0, count: 16 * 512)
        while true {
            let n = buf.withUnsafeMutableBytes { ptr -> Int in
                recv(sock, ptr.baseAddress, ptr.count, 0)
            }
            if n > 0 {
                packetsReceived += 1
                handle(Data(buf[0..<n]))
            } else {
                break
            }
        }
    }

    @discardableResult
    private func sendBytes(_ bytes: [UInt8]) -> Bool {
        guard sock >= 0 else { return false }
        var d = dest
        let sent = bytes.withUnsafeBytes { raw -> Int in
            withUnsafePointer(to: &d) { dp in
                dp.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                    sendto(sock, raw.baseAddress, raw.count, 0, sa, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
        if sent < 0 {
            let msg = String(cString: strerror(errno))
            if msg != lastError {
                lastError = msg
            }
            return false
        }
        packetsSent += 1
        return true
    }

    private func startHeartbeat() {
        heartbeat?.cancel()
        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now() + 1, repeating: 1)
        t.setEventHandler { [weak self] in self?.tick() }
        t.resume()
        heartbeat = t
    }

    private func tick() {
        guard running else { return }
        let ok = sendHello()
        let now = Date()
        if let last = lastReceive {
            if now.timeIntervalSince(last) > 5 {
                report(.noResponse)
                connect()
            }
        } else if !ok, !lastError.isEmpty {
            report(.failed(lastError))
            if now.timeIntervalSince(lastConnect) > 5 { connect() }
        } else if now.timeIntervalSince(lastConnect) > 5 {
            report(.noResponse)
            connect()
        }
    }

    @discardableResult
    private func sendHello() -> Bool {
        sendBytes(Array("ehllo".utf8))
    }

    private func sendSubscription() {
        var packet: [UInt8] = [0x0F]
        for id in subscribedIDs {
            if packet.count > 1 + 3 * 41 {
                sendBytes(packet)
                packet = [0x0F]
            }
            packet += [0xFF, UInt8((id >> 8) & 0xFF), UInt8(id & 0xFF)]
        }
        if packet.count > 1 {
            sendBytes(packet)
        }
    }

    private func handle(_ data: Data) {
        let bytes = [UInt8](data)
        guard bytes.count % 16 == 0, bytes.count <= 512 * 16 else { return }
        var frames: [CANFrame] = []
        frames.reserveCapacity(bytes.count / 16)
        var offset = 0
        var gotAck = false
        while offset + 16 <= bytes.count {
            let w0 = UInt32(bytes[offset]) | UInt32(bytes[offset + 1]) << 8
                | UInt32(bytes[offset + 2]) << 16 | UInt32(bytes[offset + 3]) << 24
            let w1 = UInt32(bytes[offset + 4]) | UInt32(bytes[offset + 5]) << 8
                | UInt32(bytes[offset + 6]) << 16 | UInt32(bytes[offset + 7]) << 24
            let extended = (w0 & 0x4) != 0
            let id = extended ? (w0 >> 3) : (w0 >> 21)
            let len = Int(w1 & 0x0F)
            let bus = UInt8((w1 >> 4) & 0xFF)
            if bus == 15 && id == 6 {
                gotAck = true
            } else if id != 0 && len >= 1 && len <= 8 {
                frames.append(CANFrame(bus: bus, id: id,
                                       data: Array(bytes[(offset + 8)..<(offset + 8 + len)])))
            }
            offset += 16
        }
        if gotAck { sendSubscription() }
        if !frames.isEmpty {
            if !reportedStreaming {
                reportedStreaming = true
                lastError = ""
                report(.streaming)
            }
            lastReceive = Date()
            onFrames?(frames)
        } else if gotAck {
            lastReceive = Date()
        }
    }

    private func report(_ s: Status) {
        onStatus?(s)
    }
}
