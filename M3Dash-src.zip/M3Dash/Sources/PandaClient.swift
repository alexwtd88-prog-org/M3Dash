import Foundation
import Network

/// One CAN frame as forwarded by the S3XY Commander over Wi-Fi.
struct CANFrame {
    let bus: UInt8
    let id: UInt32
    let data: [UInt8]
}

/// Talks to the Enhance S3XY Commander's Wi-Fi access point using the
/// comma.ai "Panda" UDP protocol (the same interface Scan My Tesla uses).
///
/// Protocol (per tumik/S3XY-candump):
///  - send "ehllo" to 192.168.4.1:1338 at least once a second to keep the session alive
///  - the Commander answers with an ACK frame (bus 15, id 6); reply with a subscription packet:
///    0x0F followed by up to 42 triples [bus(0xFF = any), idHi, idLo]
///  - data arrives as UDP datagrams holding N x 16-byte frames:
///    uint32 LE word0 (id << 21 for standard ids), uint32 LE word1 (len & 0x0F, bus = >> 4), 8 data bytes
final class PandaClient {
    enum Status: Equatable {
        case idle
        case connecting
        case streaming
        case noResponse
        case failed(String)
    }

    var onFrames: (([CANFrame]) -> Void)?
    var onStatus: ((Status) -> Void)?

    private let queue = DispatchQueue(label: "m3dash.panda")
    private var connection: NWConnection?
    private var heartbeat: DispatchSourceTimer?
    private var lastReceive: Date?
    private var lastConnect = Date()
    private var subscribedIDs: [UInt32] = []
    private var host: String = "192.168.4.1"
    private var port: UInt16 = 1338
    private var running = false

    func start(host: String, port: UInt16, ids: [UInt32]) {
        queue.async {
            self.host = host
            self.port = port
            self.subscribedIDs = ids
            self.running = true
            self.connect()
            self.startHeartbeat()
        }
    }

    func stop() {
        queue.async {
            self.running = false
            self.heartbeat?.cancel()
            self.heartbeat = nil
            self.connection?.cancel()
            self.connection = nil
            self.report(.idle)
        }
    }

    // MARK: - Connection

    private func connect() {
        connection?.cancel()
        lastReceive = nil
        lastConnect = Date()
        report(.connecting)

        let params = NWParameters.udp
        params.requiredInterfaceType = .wifi
        let conn = NWConnection(host: NWEndpoint.Host(host),
                                port: NWEndpoint.Port(rawValue: port) ?? 1338,
                                using: params)
        conn.stateUpdateHandler = { [weak self] state in
            guard let self else { return }
            switch state {
            case .ready:
                self.sendHello()
                self.sendSubscription() // harmless if early; resent on ACK
                self.receiveLoop()
            case .failed(let err):
                self.report(.failed(err.localizedDescription))
            case .waiting(let err):
                self.report(.failed(err.localizedDescription))
            default:
                break
            }
        }
        connection = conn
        conn.start(queue: queue)
    }

    private func startHeartbeat() {
        heartbeat?.cancel()
        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now() + 1, repeating: 1)
        t.setEventHandler { [weak self] in self?.tick() }
        t.resume()
        heartbeat = t
    }

    private func tick() {
        guard running else { return }
        sendHello()
        let now = Date()
        if let last = lastReceive {
            if now.timeIntervalSince(last) > 5 {
                report(.noResponse)
                connect()
            }
        } else if now.timeIntervalSince(lastConnect) > 5 {
            report(.noResponse)
            connect()
        }
    }

    private func sendHello() {
        connection?.send(content: Data("ehllo".utf8), completion: .idempotent)
    }

    private func sendSubscription() {
        guard let connection else { return }
        var packet: [UInt8] = [0x0F]
        for id in subscribedIDs {
            if packet.count > 1 + 3 * 42 {
                connection.send(content: Data(packet), completion: .idempotent)
                packet = [0x0F]
            }
            packet += [0xFF, UInt8((id >> 8) & 0xFF), UInt8(id & 0xFF)]
        }
        if packet.count > 1 {
            connection.send(content: Data(packet), completion: .idempotent)
        }
    }

    private func receiveLoop() {
        connection?.receiveMessage { [weak self] data, _, _, error in
            guard let self else { return }
            if let data, !data.isEmpty {
                self.handle(data)
            }
            if error == nil, self.running {
                self.receiveLoop()
            }
        }
    }

    private func handle(_ data: Data) {
        let bytes = [UInt8](data)
        guard bytes.count % 16 == 0, bytes.count <= 512 * 16 else { return }
        var frames: [CANFrame] = []
        frames.reserveCapacity(bytes.count / 16)
        var offset = 0
        var gotAck = false
        while offset + 16 <= bytes.count {
            let w0 = UInt32(bytes[offset]) | UInt32(bytes[offset + 1]) << 8
                | UInt32(bytes[offset + 2]) << 16 | UInt32(bytes[offset + 3]) << 24
            let w1 = UInt32(bytes[offset + 4]) | UInt32(bytes[offset + 5]) << 8
                | UInt32(bytes[offset + 6]) << 16 | UInt32(bytes[offset + 7]) << 24
            let extended = (w0 & 0x4) != 0
            let id = extended ? (w0 >> 3) : (w0 >> 21)
            let len = Int(w1 & 0x0F)
            let bus = UInt8((w1 >> 4) & 0xFF)
            if bus == 15 && id == 6 {
                gotAck = true
            } else if id != 0 && len >= 1 && len <= 8 {
                frames.append(CANFrame(bus: bus, id: id,
                                       data: Array(bytes[(offset + 8)..<(offset + 8 + len)])))
            }
            offset += 16
        }
        if gotAck { sendSubscription() }
        if !frames.isEmpty {
            if lastReceive == nil { report(.streaming) }
            lastReceive = Date()
            onFrames?(frames)
        } else if gotAck {
            lastReceive = Date()
        }
    }

    private func report(_ s: Status) {
        onStatus?(s)
    }
}
