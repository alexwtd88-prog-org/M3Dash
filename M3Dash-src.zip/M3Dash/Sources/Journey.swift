import SwiftUI
import UIKit
import UniformTypeIdentifiers

// MARK: - Export format

/// Trip history as a JSON file for ShareLink.
struct TripArchive: Transferable {
    let trips: [TripRecord]

    static var transferRepresentation: some TransferRepresentation {
        DataRepresentation(exportedContentType: .json) { archive in
            try JSONEncoder.tripEncoder.encode(archive.trips)
        }
        .suggestedFileName("M3Dash-trips.json")
    }
}

// MARK: - Wallet header

struct JourneyWallet: View {
    let trips: [TripRecord]
    let units: Units

    var body: some View {
        let miles: Double = trips.reduce(0.0) { $0 + $1.miles }
        let seconds: Double = trips.reduce(0.0) { $0 + $1.drivingSeconds }
        let kWh: Double = trips.reduce(0.0) { $0 + $1.kWh }
        let eff: Double? = miles > 0.1 ? kWh * 1000 / miles : nil
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "wallet.pass.fill")
                Text("Journey Footprints")
                    .font(.headline)
                Spacer()
                Text("\(trips.count) drives")
                    .font(.subheadline)
                    .foregroundStyle(Color.white.opacity(0.8))
            }
            HStack(alignment: .firstTextBaseline) {
                walletStat(Fmt.num(units.dist(miles), 0), units.distLabel)
                Spacer()
                walletStat(Fmt.duration(seconds: seconds), "driving")
                Spacer()
                walletStat(Fmt.num(kWh, 0), "kWh")
                Spacer()
                walletStat(Fmt.num(units.eff(eff), 0), units.effLabel)
            }
        }
        .foregroundStyle(Color.white)
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(colors: [Color(red: 0.75, green: 0.08, blue: 0.12), Color(red: 0.25, green: 0.02, blue: 0.06)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
        )
    }

    private func walletStat(_ value: String, _ unit: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(value)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(unit)
                .font(.caption)
                .foregroundStyle(Color.white.opacity(0.75))
        }
    }
}

// MARK: - Trip card

/// One finished drive. Used in the list and rendered to an image for sharing,
/// so it takes plain values and no environment objects.
struct TripCardView: View {
    let trip: TripRecord
    let units: Units
    var forSharing = false
    var onShare: (() -> Void)? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            header
            if trip.startPlace != nil || trip.endPlace != nil {
                Text("\(trip.startPlace ?? "––")  →  \(trip.endPlace ?? "––")")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            graph
            statsRow
            if forSharing {
                Text("M3 Dash")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.primary.opacity(forSharing ? 0.1 : 0.07)))
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(trip.start, format: .dateTime.weekday(.abbreviated).month(.abbreviated).day())
                .font(.headline)
            Spacer()
            Text("\(trip.start.formatted(date: .omitted, time: .shortened)) – \(trip.end.formatted(date: .omitted, time: .shortened))")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .monospacedDigit()
            if let onShare {
                Button(action: onShare) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))
                        .padding(.leading, 8)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Share this drive")
            }
        }
    }

    @ViewBuilder
    private var graph: some View {
        let points = (trip.graph ?? []).map { EnergyPoint(miles: $0.m, whPerMile: $0.w) }
        if points.count > 1 {
            EnergyGraph(points: points, reference: 245, emptyText: "")
                .frame(height: 54)
        }
    }

    private var statsRow: some View {
        HStack(alignment: .firstTextBaseline, spacing: 0) {
            cell(Fmt.num(units.dist(trip.miles), 1), units.distLabel)
            Spacer(minLength: 4)
            cell(Fmt.duration(seconds: trip.drivingSeconds), "time")
            Spacer(minLength: 4)
            cell(Fmt.num(trip.kWh, 1), "kWh")
            Spacer(minLength: 4)
            cell(Fmt.num(units.eff(trip.whPerMile), 0), units.effLabel)
            Spacer(minLength: 4)
            cell(Fmt.num(units.speed(trip.maxMph), 0), "max \(units.speedLabel)")
        }
    }

    private func cell(_ value: String, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(value)
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
    }
}

// MARK: - Month-grouped list

struct JourneyFootprints: View {
    @EnvironmentObject var store: VehicleStore
    @State private var sharing: TripRecord?

    var body: some View {
        let u = Units(metric: store.metric)
        VStack(alignment: .leading, spacing: 14) {
            JourneyWallet(trips: store.trips, units: u)
            if store.trips.isEmpty {
                Text("Finished drives show up here as cards.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            ForEach(months, id: \.self) { month in
                MonthSection(month: month,
                             trips: tripsByMonth[month] ?? [],
                             units: u,
                             onShare: { sharing = $0 })
            }
        }
        .sheet(item: $sharing) { trip in
            TripShareSheet(trip: trip, units: u)
        }
    }

    private var tripsByMonth: [Date: [TripRecord]] {
        let cal = Calendar.current
        return Dictionary(grouping: store.trips) { t in
            cal.dateInterval(of: .month, for: t.start)?.start ?? t.start
        }
    }

    private var months: [Date] {
        tripsByMonth.keys.sorted(by: >)
    }
}

struct MonthSection: View {
    let month: Date
    let trips: [TripRecord]
    let units: Units
    let onShare: (TripRecord) -> Void

    private var totalMiles: Double {
        trips.reduce(0.0) { $0 + $1.miles }
    }

    private var sortedTrips: [TripRecord] {
        trips.sorted { $0.start > $1.start }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(month, format: .dateTime.month(.wide).year())
                    .font(.title3.weight(.bold))
                Spacer()
                Text("\(Fmt.num(units.dist(totalMiles), 0)) \(units.distLabel)")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            ForEach(sortedTrips) { trip in
                TripCardView(trip: trip, units: units, onShare: { onShare(trip) })
            }
        }
    }
}

// MARK: - Share one card

struct TripShareSheet: View {
    let trip: TripRecord
    let units: Units
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @State private var image: UIImage?
    @State private var saved = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(radius: 8)
                    ShareLink(item: Image(uiImage: image),
                              preview: SharePreview("M3 Dash drive", image: Image(uiImage: image))) {
                        Label("Share", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    Button {
                        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                        saved = true
                    } label: {
                        Label(saved ? "Saved to Photos" : "Save to Photos",
                              systemImage: saved ? "checkmark" : "photo.on.rectangle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .disabled(saved)
                } else {
                    ProgressView()
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Share drive")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear { render() }
        }
    }

    @MainActor
    private func render() {
        let card = TripCardView(trip: trip, units: units, forSharing: true)
            .frame(width: 360)
            .padding(16)
            .background(DashColors.background(scheme))
            .environment(\.colorScheme, scheme)
        let renderer = ImageRenderer(content: card)
        renderer.scale = 3
        image = renderer.uiImage
    }
}
