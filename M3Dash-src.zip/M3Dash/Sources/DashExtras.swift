import SwiftUI
import UIKit

// MARK: - Car status overlay (drawn on top of CarTopShape)

/// Headlights, brake lights, blind-spot glow and open doors, in the car icon's own coordinates.
struct CarStatusOverlay: View {
    let status: CarIconStatus

    var body: some View {
        GeometryReader { g in
            let w = g.size.width
            let h = g.size.height
            ZStack {
                if status.blindLeft > 0 {
                    BlindSpotGlow(level: status.blindLeft, leftSide: true)
                        .frame(width: w * 0.35, height: h * 0.6)
                        .position(x: -w * 0.2, y: h * 0.62)
                }
                if status.blindRight > 0 {
                    BlindSpotGlow(level: status.blindRight, leftSide: false)
                        .frame(width: w * 0.35, height: h * 0.6)
                        .position(x: w * 1.2, y: h * 0.62)
                }
                if status.lowBeam || status.highBeam {
                    HeadlightBeam(high: status.highBeam)
                        .frame(width: w * 1.1, height: h * (status.highBeam ? 0.32 : 0.2))
                        .position(x: w * 0.5, y: -h * (status.highBeam ? 0.16 : 0.1))
                    lamp(color: status.highBeam ? Color(red: 0.75, green: 0.88, blue: 1) : Color(red: 1, green: 0.96, blue: 0.8),
                         w: w, h: h, y: h * 0.045, glow: 6)
                }
                if status.brake {
                    lamp(color: Color.red, w: w, h: h, y: h * 0.965, glow: 10)
                } else if status.lowBeam {
                    lamp(color: Color.red.opacity(0.55), w: w, h: h, y: h * 0.965, glow: 3)
                }
                doors(w: w, h: h)
            }
        }
        .allowsHitTesting(false)
    }

    /// A pair of lamps at the front or back corners.
    private func lamp(color: Color, w: CGFloat, h: CGFloat, y: CGFloat, glow: CGFloat) -> some View {
        ZStack {
            Capsule()
                .fill(color)
                .frame(width: w * 0.24, height: max(3, h * 0.022))
                .shadow(color: color, radius: glow)
                .position(x: w * 0.25, y: y)
            Capsule()
                .fill(color)
                .frame(width: w * 0.24, height: max(3, h * 0.022))
                .shadow(color: color, radius: glow)
                .position(x: w * 0.75, y: y)
        }
    }

    @ViewBuilder
    private func doors(w: CGFloat, h: CGFloat) -> some View {
        let open = status.doorsOpen
        if open.count == 4 {
            if open[0] { doorLine(w: w).rotationEffect(.degrees(-35)).position(x: -w * 0.12, y: h * 0.40) }
            if open[1] { doorLine(w: w).rotationEffect(.degrees(35)).position(x: w * 1.12, y: h * 0.40) }
            if open[2] { doorLine(w: w).rotationEffect(.degrees(-35)).position(x: -w * 0.1, y: h * 0.60) }
            if open[3] { doorLine(w: w).rotationEffect(.degrees(35)).position(x: w * 1.1, y: h * 0.60) }
        }
        if status.trunkOpen {
            Capsule()
                .fill(Color.orange)
                .frame(width: w * 0.7, height: 3)
                .position(x: w * 0.5, y: h * 1.06)
        }
    }

    private func doorLine(w: CGFloat) -> some View {
        Capsule()
            .fill(Color.orange)
            .frame(width: w * 0.32, height: 3)
    }
}

struct BlindSpotGlow: View {
    let level: Int
    let leftSide: Bool

    var body: some View {
        let color: Color = level >= 2 ? .red : .orange
        RoundedRectangle(cornerRadius: 12)
            .fill(LinearGradient(colors: [color.opacity(0.85), color.opacity(0.0)],
                                 startPoint: leftSide ? .trailing : .leading,
                                 endPoint: leftSide ? .leading : .trailing))
            .blur(radius: 4)
    }
}

struct HeadlightBeam: View {
    let high: Bool

    var body: some View {
        GeometryReader { g in
            let w = g.size.width
            let h = g.size.height
            Path { p in
                p.move(to: CGPoint(x: w * 0.22, y: h))
                p.addLine(to: CGPoint(x: 0, y: 0))
                p.addLine(to: CGPoint(x: w, y: 0))
                p.addLine(to: CGPoint(x: w * 0.78, y: h))
                p.closeSubpath()
            }
            .fill(LinearGradient(colors: [beamColor.opacity(0.0), beamColor.opacity(high ? 0.45 : 0.32)],
                                 startPoint: .top, endPoint: .bottom))
        }
    }

    private var beamColor: Color { high ? Color(red: 0.7, green: 0.85, blue: 1) : Color(red: 1, green: 0.95, blue: 0.7) }
}

// MARK: - Turn signal arrows

/// Green arrows that blink while a turn signal is active.
struct TurnArrows: View {
    let left: Bool
    let right: Bool
    var size: CGFloat = 30

    var body: some View {
        if left || right {
            TimelineView(.periodic(from: .now, by: 0.2)) { ctx in
                let on = Int(ctx.date.timeIntervalSinceReferenceDate / 0.4) % 2 == 0
                row(on: on)
            }
        } else {
            row(on: false)
        }
    }

    private func row(on: Bool) -> some View {
        HStack {
            arrow("arrowshape.left.fill", lit: left && on, active: left)
            Spacer()
            arrow("arrowshape.right.fill", lit: right && on, active: right)
        }
    }

    private func arrow(_ name: String, lit: Bool, active: Bool) -> some View {
        Image(systemName: name)
            .font(.system(size: size, weight: .bold))
            .foregroundStyle(lit ? Color.green : Color.primary.opacity(active ? 0.15 : 0.08))
            .shadow(color: lit ? Color.green.opacity(0.8) : Color.clear, radius: 8)
    }
}

// MARK: - Portrait compact car status

struct CarStatusStrip: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        let s = store.carStatus
        HStack(spacing: 14) {
            ZStack {
                CarTopShape()
                CarStatusOverlay(status: s)
            }
            .frame(width: 34, height: 74)
            .padding(.horizontal, 14)

            VStack(alignment: .leading, spacing: 8) {
                TurnArrows(left: s.leftTurn, right: s.rightTurn, size: 22)
                    .frame(maxWidth: 140)
                FlowChips(chips: chips(s))
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.primary.opacity(0.07)))
    }

    private func chips(_ s: CarIconStatus) -> [StatusChip] {
        var out: [StatusChip] = []
        if s.blindLeft > 0 { out.append(StatusChip(text: "Blind spot L", color: s.blindLeft >= 2 ? .red : .orange)) }
        if s.blindRight > 0 { out.append(StatusChip(text: "Blind spot R", color: s.blindRight >= 2 ? .red : .orange)) }
        if s.brake { out.append(StatusChip(text: "Brake", color: .red)) }
        if s.highBeam { out.append(StatusChip(text: "High beam", color: .blue)) }
        else if s.lowBeam { out.append(StatusChip(text: "Lights", color: .yellow)) }
        let names = ["Front left", "Front right", "Rear left", "Rear right"]
        for (i, open) in s.doorsOpen.enumerated() where open && i < names.count {
            out.append(StatusChip(text: "\(names[i]) door", color: .orange))
        }
        if s.trunkOpen { out.append(StatusChip(text: "Trunk", color: .orange)) }
        if out.isEmpty { out.append(StatusChip(text: "All clear", color: .green)) }
        return out
    }
}

struct StatusChip: Identifiable {
    var id: String { text }
    let text: String
    let color: Color
}

/// Simple wrapping row of chips (two columns grid, so it never overflows).
struct FlowChips: View {
    let chips: [StatusChip]

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 6, alignment: .leading)], alignment: .leading, spacing: 6) {
            ForEach(chips) { chip in
                Text(chip.text)
                    .font(.caption.weight(.semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Capsule().fill(chip.color.opacity(0.22)))
                    .foregroundStyle(chip.color)
            }
        }
    }
}

// MARK: - HUD (windshield reflection)

/// Mirrored, pure black, minimal cluster for reflecting off the windshield at night.
/// Double-tap anywhere to leave HUD mode.
struct HUDView: View {
    @EnvironmentObject var store: VehicleStore
    @EnvironmentObject var nav: NavigationModel
    @AppStorage("hudMode") private var hudMode = false
    @Environment(\.dashScale) private var scale

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            HStack(alignment: .center, spacing: 30) {
                turnBlock
                    .frame(maxWidth: .infinity)
                speedBlock
                limitBlock
                    .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 30)
            .foregroundStyle(Color.white)
            .scaleEffect(x: -1, y: 1)

            VStack {
                Spacer()
                Text("Double-tap to exit HUD")
                    .font(.caption2)
                    .foregroundStyle(Color.white.opacity(0.25))
                    .padding(.bottom, 6)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { hudMode = false }
    }

    private var speedBlock: some View {
        let u = Units(metric: store.metric)
        return VStack(spacing: 0) {
            Text(Fmt.num(u.speed(store.speedMph), 0).replacingOccurrences(of: "––", with: "0"))
                .font(.system(size: 150 * scale, weight: .bold, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.4)
            HStack(spacing: 14) {
                Text(store.gearLetter)
                    .font(.system(size: 40 * scale, weight: .heavy, design: .rounded))
                Text(u.speedLabel)
                    .font(.system(size: 24 * scale, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.7))
            }
        }
    }

    @ViewBuilder
    private var turnBlock: some View {
        if nav.isNavigating {
            VStack(spacing: 6) {
                Image(systemName: NavFormat.maneuverSymbol(nav.nextInstruction))
                    .font(.system(size: 70 * scale, weight: .bold))
                Text(NavFormat.distance(nav.distanceToNext))
                    .font(.system(size: 34 * scale, weight: .bold))
                    .monospacedDigit()
                Text(nav.nextInstruction ?? "")
                    .font(.system(size: 16 * scale, weight: .semibold))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .foregroundStyle(Color.white.opacity(0.8))
            }
        } else {
            TurnArrows(left: store.turnLeftActive, right: store.turnRightActive, size: 40 * scale)
                .frame(maxWidth: 160)
        }
    }

    @ViewBuilder
    private var limitBlock: some View {
        if let limit = store.snap.speedLimit {
            VStack(spacing: 2) {
                Text("LIMIT")
                    .font(.system(size: 16 * scale, weight: .bold))
                Text(String(format: "%.0f", limit))
                    .font(.system(size: 54 * scale, weight: .bold))
                    .monospacedDigit()
            }
            .padding(.horizontal, 16).padding(.vertical, 10)
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white, lineWidth: 4))
        } else {
            Color.clear.frame(width: 1, height: 1)
        }
    }
}

// MARK: - Launch effect ("Toybox")

/// Full-screen speed-streak burst when a hard launch is detected. Never blocks touches.
struct LaunchEffectOverlay: View {
    @EnvironmentObject var store: VehicleStore
    @State private var start: Date?
    private let duration: Double = 1.4

    var body: some View {
        ZStack {
            if let start {
                TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: false)) { ctx in
                    let t = max(0, min(1, ctx.date.timeIntervalSince(start) / duration))
                    StreakCanvas(progress: t)
                }
                .ignoresSafeArea()
                .transition(.opacity)
            }
        }
        .allowsHitTesting(false)
        .onChange(of: store.launchEffectCount) { _, _ in
            let enabled = (UserDefaults.standard.object(forKey: "launchEffect") as? Bool) ?? true
            guard enabled else { return }
            let now = Date()
            start = now
            let wait = UInt64((duration + 0.05) * 1_000_000_000)
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: wait)
                if start == now { start = nil }
            }
        }
    }
}

struct StreakCanvas: View {
    let progress: Double

    var body: some View {
        Canvas { ctx, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let maxR = Double(hypot(size.width, size.height)) / 2
            let fade = progress < 0.2 ? progress / 0.2 : max(0, 1 - (progress - 0.2) / 0.8)

            // Glow
            let glowRect = CGRect(x: center.x - CGFloat(maxR), y: center.y - CGFloat(maxR),
                                  width: CGFloat(maxR * 2), height: CGFloat(maxR * 2))
            ctx.fill(Path(ellipseIn: glowRect),
                     with: .radialGradient(Gradient(colors: [Color.red.opacity(0.0),
                                                             Color.red.opacity(0.0),
                                                             Color.red.opacity(0.45 * fade)]),
                                           center: center, startRadius: 0, endRadius: CGFloat(maxR)))

            // Streaks
            let count = 70
            for i in 0..<count {
                let seed = Double(i) * 2.399963   // golden angle
                let angle = seed.truncatingRemainder(dividingBy: 2 * Double.pi)
                let speed = 0.6 + (Double((i * 37) % 11) / 11.0) * 0.8
                let head = min(1.2, progress * speed * 1.6 + Double((i * 13) % 7) / 20.0)
                let tail = max(0, head - 0.25 - Double(i % 5) * 0.03)
                let r1 = maxR * (0.15 + tail)
                let r2 = maxR * (0.15 + head)
                var p = Path()
                p.move(to: CGPoint(x: center.x + CGFloat(cos(angle) * r1), y: center.y + CGFloat(sin(angle) * r1)))
                p.addLine(to: CGPoint(x: center.x + CGFloat(cos(angle) * r2), y: center.y + CGFloat(sin(angle) * r2)))
                let color: Color = i % 4 == 0 ? Color.red : Color.white
                ctx.stroke(p, with: .color(color.opacity(0.75 * fade)),
                           style: StrokeStyle(lineWidth: CGFloat(1.5 + Double(i % 3)), lineCap: .round))
            }
        }
    }
}

// MARK: - Music (Apple Music only)

/// Now playing from the Music app with play/pause, next, previous.
/// Spotify can't be shown here: reading it needs the Spotify iOS SDK, which isn't included.
struct MusicPanel: View {
    @EnvironmentObject var music: MusicModel
    var compact = false
    @Environment(\.dashScale) private var scale

    var body: some View {
        VStack(spacing: compact ? 10 : 14) {
            HStack(spacing: 14) {
                artwork
                VStack(alignment: .leading, spacing: 4) {
                    Text(music.title ?? "Nothing playing")
                        .font(.system(size: (compact ? 18 : 20) * scale, weight: .semibold))
                        .lineLimit(2)
                        .minimumScaleFactor(0.7)
                    Text(music.artist ?? "Apple Music")
                        .font(.system(size: (compact ? 14 : 16) * scale, weight: .medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            HStack(spacing: 34) {
                controlButton("backward.fill") { music.previous() }
                controlButton(music.isPlaying ? "pause.fill" : "play.fill", big: true) { music.togglePlay() }
                controlButton("forward.fill") { music.next() }
            }
            if music.authorization == .denied || music.authorization == .restricted {
                Text("Allow Media & Apple Music access in Settings to see what's playing.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                Text("Apple Music only")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(compact ? 14 : 16)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.primary.opacity(0.07)))
        .onAppear { music.activate() }
    }

    @ViewBuilder
    private var artwork: some View {
        let side: CGFloat = (compact ? 64 : 80) * scale
        if let img = music.artwork {
            Image(uiImage: img)
                .resizable()
                .scaledToFill()
                .frame(width: side, height: side)
                .clipShape(RoundedRectangle(cornerRadius: 10))
        } else {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.primary.opacity(0.1))
                .frame(width: side, height: side)
                .overlay(Image(systemName: "music.note").font(.system(size: side * 0.4)).foregroundStyle(.secondary))
        }
    }

    private func controlButton(_ symbol: String, big: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: (big ? 34 : 24) * scale, weight: .bold))
                .frame(width: 54, height: 54)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
