import SwiftUI

enum Fmt {
    static func num(_ v: Double?, _ digits: Int = 0) -> String {
        guard let v, v.isFinite else { return "––" }
        return String(format: "%.\(digits)f", v)
    }

    static func duration(minutes: Double?) -> String {
        guard let m = minutes, m.isFinite, m >= 0 else { return "––" }
        let h = Int(m) / 60, mm = Int(m) % 60
        return h > 0 ? "\(h)h \(mm)m" : "\(mm)m"
    }

    static func duration(seconds: Double) -> String { duration(minutes: seconds / 60) }
}

struct Units {
    let metric: Bool
    var speedLabel: String { metric ? "km/h" : "mph" }
    var distLabel: String { metric ? "km" : "mi" }
    var effLabel: String { metric ? "Wh/km" : "Wh/mi" }
    func speed(_ mph: Double?) -> Double? { mph.map { metric ? $0 * 1.609344 : $0 } }
    func dist(_ mi: Double?) -> Double? { mi.map { metric ? $0 * 1.609344 : $0 } }
    func eff(_ whmi: Double?) -> Double? { whmi.map { metric ? $0 / 1.609344 : $0 } }
}

struct StatTile: View {
    let title: String
    let value: String
    var unit: String = ""
    var tint: Color = .white

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title.uppercased())
                .font(.caption2.weight(.semibold))
                .foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text(value)
                    .font(.system(size: 28, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(tint)
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
                if !unit.isEmpty {
                    Text(unit).font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.07)))
    }
}

struct ConnectionBadge: View {
    @EnvironmentObject var store: VehicleStore

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(label).font(.caption.weight(.medium))
        }
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(Capsule().fill(Color.white.opacity(0.08)))
    }

    private var color: Color {
        switch store.status {
        case .streaming: return .green
        case .connecting: return .yellow
        case .noResponse, .failed: return .red
        case .idle: return .gray
        }
    }

    private var label: String {
        if store.demoMode { return "Demo" }
        switch store.status {
        case .streaming: return "Commander · \(store.framesPerSecond)/s"
        case .connecting: return "Connecting…"
        case .noResponse: return "No data – join Commander Wi-Fi"
        case .failed: return "Wi-Fi unavailable"
        case .idle: return "Disconnected"
        }
    }
}

/// Horizontal power bar: regen to the left (green), drive power to the right.
struct PowerBar: View {
    let kw: Double
    var maxDrive: Double = 300
    var maxRegen: Double = 80

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let zero = w * maxRegen / (maxDrive + maxRegen)
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.08))
                if kw >= 0 {
                    Capsule().fill(Color.red.gradient)
                        .frame(width: max(4, (w - zero) * min(kw, maxDrive) / maxDrive))
                        .offset(x: zero)
                } else {
                    let rw = zero * min(-kw, maxRegen) / maxRegen
                    Capsule().fill(Color.green.gradient)
                        .frame(width: max(4, rw))
                        .offset(x: zero - rw)
                }
                Rectangle().fill(Color.white.opacity(0.5)).frame(width: 2).offset(x: zero - 1)
            }
        }
        .frame(height: 14)
        .animation(.easeOut(duration: 0.15), value: kw)
    }
}

struct BatteryGauge: View {
    let percent: Double?

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 6).stroke(Color.white.opacity(0.4), lineWidth: 2)
                RoundedRectangle(cornerRadius: 4)
                    .fill(fill)
                    .frame(width: max(0, (geo.size.width - 6) * CGFloat((percent ?? 0) / 100)))
                    .padding(3)
            }
        }
        .frame(height: 26)
    }

    private var fill: Color {
        guard let p = percent else { return .gray }
        return p < 15 ? .red : (p < 30 ? .orange : .green)
    }
}
