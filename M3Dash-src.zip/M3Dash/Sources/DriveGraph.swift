import SwiftUI

/// Tesla-style "Current Drive" card: consumption graph plus totals.
struct CurrentDriveCard: View {
    @EnvironmentObject var store: VehicleStore
    var compact = false

    var body: some View {
        let u = Units(metric: store.metric)
        let rated = store.snap.ratedWhPerMi ?? 245
        VStack(alignment: .leading, spacing: compact ? 8 : 12) {
            Text("Current Drive")
                .font(.system(size: compact ? 18 : 20, weight: .semibold))

            EnergyGraph(points: store.driveGraph, reference: rated)
                .frame(height: compact ? 70 : 90)

            HStack(alignment: .firstTextBaseline) {
                stat(Fmt.num(u.eff(store.drive?.whPerMile), 1), u.effLabel)
                Spacer(minLength: 8)
                stat(Fmt.num(store.drive?.kWh, 1), "kWh")
                Spacer(minLength: 8)
                stat(Fmt.num(u.dist(store.drive?.miles), 1), u.distLabel)
                Spacer(minLength: 8)
                stat(Fmt.num(u.dist(store.projectedRangeMiles), 0), u.distLabel)
            }
        }
        .padding(compact ? 14 : 16)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.07)))
    }

    private func stat(_ v: String, _ unit: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 4) {
            Text(v)
                .font(.system(size: compact ? 18 : 22, weight: .semibold))
                .monospacedDigit()
            Text(unit)
                .font(.system(size: compact ? 13 : 15, weight: .medium))
                .foregroundStyle(.secondary)
        }
        .lineLimit(1)
        .minimumScaleFactor(0.6)
    }
}

/// Line of Wh/mi over distance. Orange above the rated line, green below it.
struct EnergyGraph: View {
    let points: [EnergyPoint]
    let reference: Double

    var body: some View {
        Canvas { ctx, size in
            let values = points.map(\.whPerMile)
            let lo = min(values.min() ?? 0, reference * 0.4)
            let hi = max(values.max() ?? 0, reference * 1.6)
            let span = max(hi - lo, 1)
            func y(_ v: Double) -> CGFloat { size.height * CGFloat(1 - (v - lo) / span) }

            // rated reference line
            let refY = y(reference)
            var ref = Path()
            ref.move(to: CGPoint(x: 0, y: refY))
            ref.addLine(to: CGPoint(x: size.width, y: refY))
            ctx.stroke(ref, with: .color(.white.opacity(0.18)), lineWidth: 1)

            guard points.count > 1,
                  let first = points.first?.miles, let last = points.last?.miles, last > first else {
                return
            }
            let xSpan = last - first
            var line = Path()
            for (i, p) in points.enumerated() {
                let pt = CGPoint(x: size.width * CGFloat((p.miles - first) / xSpan), y: y(p.whPerMile))
                if i == 0 { line.move(to: pt) } else { line.addLine(to: pt) }
            }
            let split = max(0, min(1, refY / max(size.height, 1)))
            let shading = GraphicsContext.Shading.linearGradient(
                Gradient(stops: [
                    .init(color: .orange, location: 0),
                    .init(color: .orange, location: split),
                    .init(color: .green, location: split),
                    .init(color: .green, location: 1)
                ]),
                startPoint: .zero,
                endPoint: CGPoint(x: 0, y: size.height))
            ctx.stroke(line, with: shading, style: StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
        }
        .overlay {
            if points.count < 2 {
                Text("Graph starts once you're driving")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
